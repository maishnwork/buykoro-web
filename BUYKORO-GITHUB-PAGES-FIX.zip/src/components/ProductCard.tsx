import React from 'react';
import { Star, ShoppingBag, Eye, Zap } from 'lucide-react';
import { Product } from '../types';
import { formatBDT, calculateDiscountPercent } from '../utils/delivery';

interface ProductCardProps {
  product: Product;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product, size?: string) => void;
  onDirectBuyNow: (product: Product, size?: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onQuickView,
  onAddToCart,
  onDirectBuyNow
}) => {
  const discount = calculateDiscountPercent(product.price, product.originalPrice);
  const primaryImage = product.images?.[0] || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=80';
  const secondaryImage = product.images?.[1] || primaryImage;

  return (
    <div className="group relative bg-white rounded-xl overflow-hidden border border-[#e8e2d5] hover:border-[#cfc6b4] hover:shadow-xl transition-all duration-300 flex flex-col h-full">
      {/* Image Container */}
      <div className="relative aspect-[3/4] overflow-hidden bg-[#f4f1eb]">
        <img
          src={primaryImage}
          alt={product.title}
          className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105 group-hover:opacity-0"
          loading="lazy"
        />
        <img
          src={secondaryImage}
          alt={`${product.title} detail`}
          className="w-full h-full object-cover object-top absolute inset-0 opacity-0 group-hover:opacity-100 transition-all duration-700 group-hover:scale-105"
          loading="lazy"
        />

        {/* Top Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 z-10">
          {product.badge && (
            <span className="px-2.5 py-1 rounded-sm bg-[#191816]/90 backdrop-blur-sm text-[#e6c97a] text-[10px] font-semibold tracking-wider uppercase shadow-sm">
              {product.badge}
            </span>
          )}
          {discount > 0 && (
            <span className="px-2 py-0.5 rounded-sm bg-[#991b1b] text-white text-[10px] font-bold tracking-wider uppercase shadow-sm w-fit">
              -{discount}% OFF
            </span>
          )}
        </div>

        {/* Stock status indicator */}
        {!product.inStock ? (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] flex items-center justify-center z-20">
            <span className="px-3 py-1.5 rounded-full bg-white text-[#191816] font-bold text-xs uppercase tracking-wider">
              Sold Out
            </span>
          </div>
        ) : product.stockCount && product.stockCount <= 5 ? (
          <span className="absolute bottom-2.5 left-2.5 px-2 py-0.5 rounded bg-amber-500/90 text-white text-[9px] font-bold tracking-wider uppercase shadow-sm z-10">
            Only {product.stockCount} left
          </span>
        ) : null}

        {/* Hover Quick Action Buttons */}
        <div className="absolute inset-x-3 bottom-3 flex items-center gap-2 translate-y-6 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300 z-20">
          <button
            onClick={() => onQuickView(product)}
            className="flex-1 py-2.5 px-3 rounded-lg bg-white/95 backdrop-blur-md text-[#191816] hover:bg-white text-xs font-semibold tracking-wider uppercase shadow-md flex items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer"
            aria-label={`Quick view ${product.title}`}
          >
            <Eye className="w-3.5 h-3.5 text-[#7a7469]" />
            Quick View
          </button>
          <button
            onClick={() => onAddToCart(product)}
            disabled={!product.inStock}
            className="p-2.5 rounded-lg bg-[#191816] hover:bg-[#2b2723] text-[#faf9f5] shadow-md transition active:scale-95 disabled:opacity-50 cursor-pointer"
            aria-label={`Add ${product.title} to bag`}
            title="Add to Bag"
          >
            <ShoppingBag className="w-4 h-4 text-[#d4af37]" />
          </button>
        </div>
      </div>

      {/* Product Details Section */}
      <div className="p-4 flex flex-col flex-1 justify-between gap-3">
        <div>
          <div className="flex items-center justify-between text-[11px] text-[#857b6d] mb-1">
            <span className="uppercase tracking-wider font-medium">{product.category}</span>
            <div className="flex items-center gap-1 text-[#d4af37]">
              <Star className="w-3 h-3 fill-current" />
              <span className="font-semibold text-[#191816] text-xs">{product.rating}</span>
              <span className="text-[#9c9384]">({product.reviewCount})</span>
            </div>
          </div>

          <h3
            onClick={() => onQuickView(product)}
            className="font-serif text-sm sm:text-base font-semibold text-[#191816] line-clamp-1 hover:text-[#d4af37] transition cursor-pointer"
          >
            {product.title}
          </h3>

          <p className="text-xs text-[#70685c] line-clamp-1 mt-0.5">
            {product.fabric || product.subtitle || 'Premium Handcrafted Collection'}
          </p>
        </div>

        {/* Pricing & Fast Checkout */}
        <div className="pt-2 border-t border-[#f0ebd9] flex items-center justify-between">
          <div>
            <div className="flex items-baseline gap-2">
              <span className="text-base sm:text-lg font-bold text-[#191816]">
                {formatBDT(product.price)}
              </span>
              {product.originalPrice && product.originalPrice > product.price && (
                <span className="text-xs text-[#9c9384] line-through">
                  {formatBDT(product.originalPrice)}
                </span>
              )}
            </div>
            <p className="text-[10px] text-emerald-700 font-medium">Cash on Delivery Available</p>
          </div>

          <button
            onClick={() => onDirectBuyNow(product)}
            disabled={!product.inStock}
            className="px-3 py-1.5 rounded-full bg-[#191816] hover:bg-[#d4af37] text-white hover:text-[#191816] text-[11px] font-semibold tracking-wider uppercase transition-all shadow-sm flex items-center gap-1 cursor-pointer disabled:opacity-40"
          >
            <Zap className="w-3 h-3 text-[#d4af37] group-hover:text-[#191816]" />
            Order
          </button>
        </div>
      </div>
    </div>
  );
};
