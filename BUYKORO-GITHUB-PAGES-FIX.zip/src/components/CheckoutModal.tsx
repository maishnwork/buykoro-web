import React, { useState } from 'react';
import { X, ShieldCheck, Truck, CheckCircle2, Copy, Check, ArrowRight, Phone, AlertCircle } from 'lucide-react';
import confetti from 'canvas-confetti';
import { CartItem, Order, StoreSettings } from '../types';
import {
  BANGLADESH_DISTRICTS,
  calculateDeliveryFee,
  formatBDT,
  isValidBdPhone,
  generateOrderId
} from '../utils/delivery';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onOrderPlaced: (order: Order) => Promise<void>;
  storeSettings: StoreSettings;
  onTrackOrder: (orderId: string) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  onOrderPlaced,
  storeSettings,
  onTrackOrder
}) => {
  if (!isOpen) return null;

  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [alternativePhone, setAlternativePhone] = useState('');
  const [district, setDistrict] = useState('Dhaka (Inside City)');
  const [thana, setThana] = useState('');
  const [address, setAddress] = useState('');
  const [instructions, setInstructions] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const deliveryFee = calculateDeliveryFee(subtotal, district, storeSettings);
  const grandTotal = subtotal + deliveryFee;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!customerName.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }

    if (!isValidBdPhone(phone)) {
      setErrorMessage('Please enter a valid 11-digit Bangladeshi mobile number (e.g., 01712345678).');
      return;
    }

    if (!district) {
      setErrorMessage('Please select your delivery district.');
      return;
    }

    if (!address.trim() || address.trim().length < 8) {
      setErrorMessage('Please enter your complete street address (House, Road, Area).');
      return;
    }

    if (cartItems.length === 0) {
      setErrorMessage('Your bag is empty.');
      return;
    }

    setIsSubmitting(true);

    try {
      const orderPayload: Order = {
        orderId: generateOrderId(),
        customerName: customerName.trim(),
        phone: phone.trim(),
        alternativePhone: alternativePhone.trim(),
        district,
        thana: thana.trim(),
        address: address.trim(),
        instructions: instructions.trim(),
        items: cartItems.map(item => ({
          productId: item.product.id,
          title: item.product.title,
          size: item.selectedSize,
          price: item.product.price,
          quantity: item.quantity,
          image: item.product.images?.[0] || ''
        })),
        subtotal,
        deliveryFee,
        total: grandTotal,
        paymentMethod: 'Cash on Delivery (COD)',
        status: 'pending',
        createdAt: new Date().toISOString()
      };

      await onOrderPlaced(orderPayload);
      setCompletedOrder(orderPayload);

      try {
        confetti({
          particleCount: 120,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch {
        // silent
      }
    } catch (err: any) {
      console.error('Order placement failed:', err);
      setErrorMessage('Failed to submit order. Please try again or call our customer hotline.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyId = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-[#faf9f5] rounded-2xl shadow-2xl border border-[#e5dfd3] overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-white border-b border-[#e5dfd3] flex items-center justify-between shrink-0">
          <div>
            <h2 className="font-serif text-lg sm:text-xl font-bold text-[#191816]">
              {completedOrder ? 'Order Confirmed!' : 'Cash on Delivery Checkout'}
            </h2>
            <p className="text-xs text-[#736c61]">
              {completedOrder
                ? 'Thank you for shopping with BUYKORO Dhaka.'
                : 'Zero online payment required • Pay cash upon delivery'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-[#efebe2] text-[#736c61] hover:text-[#191816] transition cursor-pointer"
            aria-label="Close checkout"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="overflow-y-auto p-4 sm:p-6 flex-1">
          {completedOrder ? (
            <div className="text-center py-6 space-y-6">
              <div className="w-20 h-20 rounded-full bg-emerald-100 border-2 border-emerald-500 text-emerald-700 flex items-center justify-center mx-auto shadow-md">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <span className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
                  Order Successfully Placed
                </span>
                <h3 className="font-serif text-2xl font-bold text-[#191816] mt-1">
                  Thank You, {completedOrder.customerName}!
                </h3>
                <p className="text-xs sm:text-sm text-[#736c61] max-w-md mx-auto mt-2 leading-relaxed">
                  Your order has been received by BUYKORO logistics. Our representative will call you on <strong className="text-[#191816]">{completedOrder.phone}</strong> before dispatch.
                </p>
              </div>

              <div className="max-w-md mx-auto p-4 rounded-xl bg-white border border-[#e5dfd3] shadow-xs flex items-center justify-between">
                <div className="text-left">
                  <p className="text-[11px] font-bold text-[#8a8274] uppercase tracking-wider">
                    Your Order ID
                  </p>
                  <p className="font-mono text-xl font-extrabold text-[#191816]">
                    {completedOrder.orderId}
                  </p>
                </div>
                <button
                  onClick={() => handleCopyId(completedOrder.orderId)}
                  className="px-3 py-1.5 rounded-lg bg-[#efebe2] hover:bg-[#e2dacb] text-xs font-medium text-[#191816] flex items-center gap-1.5 transition cursor-pointer"
                >
                  {copiedId ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedId ? 'Copied' : 'Copy'}
                </button>
              </div>

              <div className="max-w-md mx-auto p-4 rounded-xl bg-[#efebe2]/60 border border-[#e2dccf] text-left text-xs space-y-2">
                <div className="flex justify-between text-[#736c61]">
                  <span>Delivery Address:</span>
                  <span className="font-medium text-[#191816] text-right max-w-[240px] truncate">{completedOrder.address}, {completedOrder.district}</span>
                </div>
                <div className="flex justify-between text-[#736c61]">
                  <span>Payment Method:</span>
                  <span className="font-semibold text-emerald-800">Cash on Delivery (COD)</span>
                </div>
                <div className="flex justify-between text-[#736c61] pt-2 border-t border-[#dbd4c4]">
                  <span className="font-bold text-[#191816]">Total Payable to Rider:</span>
                  <span className="font-bold text-base text-[#191816]">{formatBDT(completedOrder.total)}</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <button
                  onClick={() => {
                    onClose();
                    onTrackOrder(completedOrder.orderId);
                  }}
                  className="w-full sm:w-auto px-6 py-3 rounded-xl bg-[#191816] text-[#faf9f5] hover:bg-[#332f2a] text-xs font-bold uppercase tracking-wider shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Truck className="w-4 h-4 text-[#d4af37]" />
                  Track Live Status
                </button>
                <button
                  onClick={onClose}
                  className="w-full sm:w-auto px-6 py-3 rounded-xl bg-white border border-[#d6cfc1] text-[#191816] hover:bg-[#f4efe6] text-xs font-bold uppercase tracking-wider transition cursor-pointer"
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              {errorMessage && (
                <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              <div className="p-3.5 rounded-xl bg-amber-50/80 border border-amber-200 text-amber-900 text-xs flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-amber-800 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-semibold">Bangladeshi Cash on Delivery (COD):</strong>
                  <p className="text-[11px] text-amber-800/90 mt-0.5">
                    No card or bKash needed upfront. Inspect your garment packaging upon courier delivery and pay cash directly to the delivery person.
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="font-serif text-sm font-bold uppercase tracking-wider text-[#191816]">
                  1. Contact Details
                </h3>

                <div>
                  <label className="block text-xs font-semibold text-[#3b362e] mb-1">
                    Customer Full Name <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Tanvir Ahmed"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-[#d6cfc1] bg-white text-xs text-[#191816] focus:outline-none focus:ring-1 focus:ring-[#191816]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-[#3b362e] mb-1">
                      Mobile Number (11 Digits) <span className="text-red-600">*</span>
                    </label>
                    <div className="relative">
                      <Phone className="w-3.5 h-3.5 text-[#8a8274] absolute left-3 top-3" />
                      <input
                        type="tel"
                        required
                        placeholder="01712345678"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full pl-9 pr-3.5 py-2.5 rounded-lg border border-[#d6cfc1] bg-white text-xs text-[#191816] focus:outline-none focus:ring-1 focus:ring-[#191816]"
                      />
                    </div>
                    <span className="text-[10px] text-[#8a8274]">
                      We will call this number for dispatch verification.
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#3b362e] mb-1">
                      Alternative Mobile (Optional)
                    </label>
                    <input
                      type="tel"
                      placeholder="01912345678"
                      value={alternativePhone}
                      onChange={(e) => setAlternativePhone(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-[#d6cfc1] bg-white text-xs text-[#191816] focus:outline-none focus:ring-1 focus:ring-[#191816]"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-3 pt-3 border-t border-[#e5dfd3]">
                <h3 className="font-serif text-sm font-bold uppercase tracking-wider text-[#191816]">
                  2. Bangladesh Delivery Address
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-[#3b362e] mb-1">
                      District (64 Districts) <span className="text-red-600">*</span>
                    </label>
                    <select
                      value={district}
                      onChange={(e) => setDistrict(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-[#d6cfc1] bg-white text-xs text-[#191816] focus:outline-none focus:ring-1 focus:ring-[#191816]"
                    >
                      {BANGLADESH_DISTRICTS.map((dist) => (
                        <option key={dist.name} value={dist.name}>
                          {dist.name} ({dist.division})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#3b362e] mb-1">
                      Thana / Upazila / Police Station
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Dhanmondi, Gulshan, Agrabad"
                      value={thana}
                      onChange={(e) => setThana(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-[#d6cfc1] bg-white text-xs text-[#191816] focus:outline-none focus:ring-1 focus:ring-[#191816]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#3b362e] mb-1">
                    Detailed Street Address <span className="text-red-600">*</span>
                  </label>
                  <textarea
                    required
                    rows={2}
                    placeholder="House Number, Flat / Floor, Road Number, Block / Sector, Landmark"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-lg border border-[#d6cfc1] bg-white text-xs text-[#191816] focus:outline-none focus:ring-1 focus:ring-[#191816]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#3b362e] mb-1">
                    Special Delivery Instructions (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Call before arrival, leave at security desk"
                    value={instructions}
                    onChange={(e) => setInstructions(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-lg border border-[#d6cfc1] bg-white text-xs text-[#191816] focus:outline-none focus:ring-1 focus:ring-[#191816]"
                  />
                </div>
              </div>

              <div className="p-4 rounded-xl bg-white border border-[#e5dfd3] space-y-2 text-xs">
                <div className="flex justify-between text-[#736c61]">
                  <span>Items Subtotal ({cartItems.reduce((a, b) => a + b.quantity, 0)} items):</span>
                  <span className="font-semibold text-[#191816]">{formatBDT(subtotal)}</span>
                </div>

                <div className="flex justify-between text-[#736c61]">
                  <span>Delivery Charge ({district}):</span>
                  <span className="font-semibold text-[#191816]">
                    {deliveryFee === 0 ? (
                      <span className="text-emerald-700 font-bold">FREE (Above Threshold)</span>
                    ) : (
                      formatBDT(deliveryFee)
                    )}
                  </span>
                </div>

                <div className="pt-2 border-t border-[#f2ede4] flex justify-between items-baseline">
                  <div>
                    <span className="text-sm font-bold text-[#191816]">Total Amount to Pay:</span>
                    <p className="text-[10px] text-emerald-700">Cash on Delivery</p>
                  </div>
                  <span className="text-xl font-extrabold text-[#191816]">
                    {formatBDT(grandTotal)}
                  </span>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 rounded-xl bg-[#191816] hover:bg-[#332f2a] text-[#faf9f5] font-bold text-xs uppercase tracking-wider shadow-xl transition flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50 cursor-pointer"
              >
                {isSubmitting ? (
                  <span>Securing Order...</span>
                ) : (
                  <>
                    <span>Confirm Order with Cash on Delivery ({formatBDT(grandTotal)})</span>
                    <ArrowRight className="w-4 h-4 text-[#d4af37]" />
                  </>
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
