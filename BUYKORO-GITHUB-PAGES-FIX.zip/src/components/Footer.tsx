import React from 'react';
import { MapPin, Phone, Mail, ShieldCheck, Truck, RotateCcw, Heart } from 'lucide-react';
import { ProductCategory, StoreSettings } from '../types';
import { formatBDT } from '../utils/delivery';

interface FooterProps {
  onSelectCategory: (category: ProductCategory) => void;
  onOpenTrackOrder: () => void;
  onOpenAdmin: () => void;
  storeSettings: StoreSettings;
}

export const Footer: React.FC<FooterProps> = ({
  onSelectCategory,
  onOpenTrackOrder,
  onOpenAdmin,
  storeSettings
}) => {
  return (
    <footer className="bg-[#121110] text-[#e8dfc8] border-t border-[#292622]">
      {/* Trust bar */}
      <div className="border-b border-[#24211d] py-8">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-center sm:text-left">
            <div className="flex items-center sm:items-start gap-3 justify-center sm:justify-start">
              <div className="p-2.5 rounded-xl bg-[#221e1a] text-[#d4af37] border border-[#3b352b]">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-serif text-sm font-bold text-white">64 Districts COD</h4>
                <p className="text-xs text-[#a69d8d] mt-0.5">Cash on delivery across all Bangladesh</p>
              </div>
            </div>

            <div className="flex items-center sm:items-start gap-3 justify-center sm:justify-start">
              <div className="p-2.5 rounded-xl bg-[#221e1a] text-[#d4af37] border border-[#3b352b]">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-serif text-sm font-bold text-white">100% Handloom Authentic</h4>
                <p className="text-xs text-[#a69d8d] mt-0.5">Dhakai Muslin & Pure Silk certs</p>
              </div>
            </div>

            <div className="flex items-center sm:items-start gap-3 justify-center sm:justify-start">
              <div className="p-2.5 rounded-xl bg-[#221e1a] text-[#d4af37] border border-[#3b352b]">
                <RotateCcw className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-serif text-sm font-bold text-white">7-Day Easy Exchange</h4>
                <p className="text-xs text-[#a69d8d] mt-0.5">Hassle-free size replacement</p>
              </div>
            </div>

            <div className="flex items-center sm:items-start gap-3 justify-center sm:justify-start">
              <div className="p-2.5 rounded-xl bg-[#221e1a] text-[#d4af37] border border-[#3b352b]">
                <Heart className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-serif text-sm font-bold text-white">Dhaka Haute Couture</h4>
                <p className="text-xs text-[#a69d8d] mt-0.5">Designed and tailored in Dhaka</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="container mx-auto px-4 sm:px-6 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-sm bg-[#faf9f5] flex items-center justify-center text-[#191816] font-serif font-black text-xl shadow-sm">
                B
              </div>
              <div>
                <h2 className="font-serif text-2xl font-black tracking-[0.2em] text-white uppercase">
                  BUYKORO
                </h2>
                <p className="text-[9px] tracking-[0.3em] uppercase text-[#d4af37] font-semibold -mt-1">
                  Dhaka • Bangladesh
                </p>
              </div>
            </div>

            <p className="text-xs text-[#a69d8d] max-w-sm leading-relaxed">
              BUYKORO is an exclusive fashion house celebrating heritage craftsmanship. We bring heirloom Jamdani, imperial zardozi Panjabis, and modern linen silhouettes directly to your door with zero-advance Cash on Delivery.
            </p>

            <div className="pt-2 text-xs space-y-1.5 text-[#cfc6b4]">
              <p className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#d4af37]" />
                Banani Road 11, Dhaka 1213, Bangladesh
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#d4af37]" />
                Helpline: {storeSettings.supportPhone || '+880 1711-000000'} (10 AM - 10 PM)
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#d4af37]" />
                concierge@buykoro.com
              </p>
            </div>
          </div>

          {/* Collections */}
          <div>
            <h3 className="font-serif text-xs font-bold uppercase tracking-widest text-white mb-4">
              Couture Drops
            </h3>
            <ul className="space-y-2 text-xs text-[#a69d8d]">
              <li>
                <button
                  onClick={() => onSelectCategory('Festive Panjabi')}
                  className="hover:text-[#d4af37] transition cursor-pointer"
                >
                  Festive Panjabi 2026
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('Royal Sarees')}
                  className="hover:text-[#d4af37] transition cursor-pointer"
                >
                  Dhakai Jamdani & Katan
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('Luxury Kurtis & Salwar')}
                  className="hover:text-[#d4af37] transition cursor-pointer"
                >
                  Luxury Kurtis & Anarkalis
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('Contemporary Fusion')}
                  className="hover:text-[#d4af37] transition cursor-pointer"
                >
                  Indo-Western Fusion & Bundi
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('Footwear & Accessories')}
                  className="hover:text-[#d4af37] transition cursor-pointer"
                >
                  Handcrafted Mojari & Footwear
                </button>
              </li>
            </ul>
          </div>

          {/* Customer Care */}
          <div>
            <h3 className="font-serif text-xs font-bold uppercase tracking-widest text-white mb-4">
              Customer Support
            </h3>
            <ul className="space-y-2 text-xs text-[#a69d8d]">
              <li>
                <button
                  onClick={onOpenTrackOrder}
                  className="hover:text-[#d4af37] transition cursor-pointer text-left"
                >
                  Track Parcel Status
                </button>
              </li>
              <li>
                <span className="hover:text-[#d4af37] transition cursor-pointer">
                  Cash on Delivery Guide
                </span>
              </li>
              <li>
                <span className="hover:text-[#d4af37] transition cursor-pointer">
                  Standard Size Charts
                </span>
              </li>
              <li>
                <span className="hover:text-[#d4af37] transition cursor-pointer">
                  Exchange & Return Policy
                </span>
              </li>
              <li>
                <span className="hover:text-[#d4af37] transition cursor-pointer">
                  Fabric Care & Preservation
                </span>
              </li>
            </ul>
          </div>

          {/* Nationwide Coverage */}
          <div>
            <h3 className="font-serif text-xs font-bold uppercase tracking-widest text-white mb-4">
              Courier Network
            </h3>
            <p className="text-xs text-[#a69d8d] leading-relaxed mb-3">
              Daily dispatches via Pathao Courier, Steadfast & eCourier to:
            </p>
            <div className="flex flex-wrap gap-1 text-[11px] text-[#cfc6b4]">
              {['Dhaka', 'Chattogram', 'Sylhet', 'Rajshahi', 'Khulna', 'Barishal', 'Rangpur', 'Mymensingh', 'Cox\'s Bazar', 'Gazipur', 'Cumilla'].map(c => (
                <span key={c} className="px-2 py-0.5 rounded bg-[#1e1b17] border border-[#332e26]">
                  {c}
                </span>
              ))}
            </div>
            <div className="mt-4 pt-3 border-t border-[#292622]">
              <button
                onClick={onOpenAdmin}
                className="text-xs text-[#a69d8d] hover:text-[#d4af37] flex items-center gap-1.5 transition cursor-pointer"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-[#d4af37]" />
                Staff Admin Portal
              </button>
            </div>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="mt-12 pt-6 border-t border-[#24211d] flex flex-col sm:flex-row items-center justify-between text-xs text-[#736c61] gap-3">
          <p>© 2026 BUYKORO Bangladesh. All rights reserved. Dhaka, Bangladesh.</p>
          <p className="text-[#a69d8d]">
            Cash on Delivery • Free Delivery on orders over {formatBDT(storeSettings.freeDeliveryThreshold || 3000)}
          </p>
        </div>
      </div>
    </footer>
  );
};
