import React, { useState } from 'react';
import { X, Star, ShoppingBag, Zap, Shield, Truck, RotateCcw, Check, Ruler } from 'lucide-react';
import { Product } from '../types';
import { formatBDT, calculateDiscountPercent } from '../utils/delivery';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, size: string, quantity: number) => void;
  onDirectBuyNow: (product: Product, size: string, quantity: number) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onDirectBuyNow
}) => {
  if (!product) return null;

  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes?.[0] || 'Standard');
  const [quantity, setQuantity] = useState(1);
  const [showSizeGuide, setShowSizeGuide] = useState(false);
  const [addedAnimation, setAddedAnimation] = useState(false);

  const discount = calculateDiscountPercent(product.price, product.originalPrice);
  const images = product.images && product.images.length > 0
    ? product.images
    : ['https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=1000&q=80'];

  const handleAdd = () => {
    onAddToCart(product, selectedSize, quantity);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1500);
  };

  const handleBuy = () => {
    onDirectBuyNow(product, selectedSize, quantity);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-[#faf9f5] rounded-2xl shadow-2xl overflow-hidden border border-[#e5dfd3] my-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-white/90 hover:bg-white text-[#191816] shadow-md transition active:scale-95 cursor-pointer"
          aria-label="Close product modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Left Column: Image Gallery */}
          <div className="p-4 sm:p-6 bg-[#f4efe6] flex flex-col items-center justify-center">
            <div className="relative w-full aspect-[3/4] rounded-xl overflow-hidden shadow-inner bg-white">
              <img
                src={images[selectedImage] || images[0]}
                alt={product.title}
                className="w-full h-full object-cover object-top"
              />
              {product.badge && (
                <span className="absolute top-3 left-3 px-3 py-1 rounded-sm bg-[#191816] text-[#e6c97a] text-xs font-semibold tracking-wider uppercase">
                  {product.badge}
                </span>
              )}
            </div>

            {images.length > 1 && (
              <div className="flex items-center gap-2 mt-4 overflow-x-auto pb-1 max-w-full">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`relative w-16 h-20 rounded-lg overflow-hidden border-2 transition-all shrink-0 cursor-pointer ${
                      selectedImage === idx ? 'border-[#d4af37] ring-1 ring-[#d4af37]' : 'border-transparent opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="thumbnail" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Column: Product Details & Actions */}
          <div className="p-6 sm:p-8 flex flex-col justify-between max-h-[85vh] overflow-y-auto">
            <div>
              <div className="flex items-center justify-between text-xs text-[#827a6e] mb-1">
                <span className="uppercase tracking-widest font-semibold">{product.category}</span>
                <div className="flex items-center gap-1.5 text-[#d4af37]">
                  <Star className="w-4 h-4 fill-current" />
                  <span className="font-bold text-[#191816] text-sm">{product.rating}</span>
                  <span className="text-[#8c8477]">({product.reviewCount} reviews)</span>
                </div>
              </div>

              <h2 className="font-serif text-2xl sm:text-3xl font-medium text-[#191816] leading-tight">
                {product.title}
              </h2>

              <p className="text-xs sm:text-sm text-[#70685c] mt-1 font-medium">
                {product.fabric || product.subtitle}
              </p>

              <div className="mt-4 p-3.5 rounded-xl bg-[#efe9dd]/60 border border-[#e2dacb] flex items-baseline justify-between">
                <div>
                  <span className="text-2xl sm:text-3xl font-bold text-[#191816]">
                    {formatBDT(product.price)}
                  </span>
                  {product.originalPrice && product.originalPrice > product.price && (
                    <span className="ml-3 text-sm text-[#8c8477] line-through">
                      {formatBDT(product.originalPrice)}
                    </span>
                  )}
                </div>
                {discount > 0 && (
                  <span className="px-2.5 py-1 rounded bg-[#991b1b] text-white text-xs font-bold tracking-wider uppercase">
                    Save {discount}%
                  </span>
                )}
              </div>

              <p className="mt-4 text-xs sm:text-sm text-[#575147] leading-relaxed">
                {product.description}
              </p>

              {product.sizes && product.sizes.length > 0 && (
                <div className="mt-6">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-[#191816]">
                      Select Size: <span className="font-medium text-[#7a7469]">{selectedSize}</span>
                    </label>
                    <button
                      onClick={() => setShowSizeGuide(!showSizeGuide)}
                      className="text-xs font-semibold text-[#8c6d1f] hover:text-[#b88f28] flex items-center gap-1 cursor-pointer"
                    >
                      <Ruler className="w-3.5 h-3.5" />
                      Size Guide
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {product.sizes.map((size) => (
                      <button
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={`px-4 py-2 rounded-lg text-xs font-medium transition cursor-pointer ${
                          selectedSize === size
                            ? 'bg-[#191816] text-[#faf9f5] shadow-sm'
                            : 'bg-white border border-[#d6cfc1] text-[#3b362e] hover:border-[#191816]'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>

                  {showSizeGuide && (
                    <div className="mt-3 p-3 rounded-lg bg-white border border-[#e2dacb] text-xs space-y-2 animate-fadeIn">
                      <p className="font-bold text-[#191816]">Standard Measurement Guide (Inches):</p>
                      <table className="w-full text-left text-[11px] border-collapse">
                        <thead>
                          <tr className="border-b border-[#eee]">
                            <th className="py-1">Size</th>
                            <th className="py-1">Chest</th>
                            <th className="py-1">Length</th>
                            <th className="py-1">Sleeve</th>
                          </tr>
                        </thead>
                        <tbody className="text-[#595349]">
                          <tr className="border-b border-[#f5f5f5]"><td className="py-1 font-semibold">38 / S</td><td>38"-40"</td><td>40"</td><td>24.5"</td></tr>
                          <tr className="border-b border-[#f5f5f5]"><td className="py-1 font-semibold">40 / M</td><td>40"-42"</td><td>42"</td><td>25"</td></tr>
                          <tr className="border-b border-[#f5f5f5]"><td className="py-1 font-semibold">42 / L</td><td>42"-44"</td><td>44"</td><td>25.5"</td></tr>
                          <tr><td className="py-1 font-semibold">44 / XL</td><td>44"-46"</td><td>45"</td><td>26"</td></tr>
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}

              <div className="mt-5 flex items-center gap-4">
                <span className="text-xs font-bold uppercase tracking-wider text-[#191816]">Quantity:</span>
                <div className="flex items-center border border-[#d6cfc1] rounded-lg bg-white">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-1 text-sm font-bold text-[#443e34] hover:bg-[#f4efe6] transition"
                  >
                    -
                  </button>
                  <span className="px-3 py-1 text-xs font-bold text-[#191816] min-w-8 text-center">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-1 text-sm font-bold text-[#443e34] hover:bg-[#f4efe6] transition"
                  >
                    +
                  </button>
                </div>
              </div>

              {product.details && product.details.length > 0 && (
                <div className="mt-6 pt-4 border-t border-[#e2dacb]">
                  <p className="text-xs font-bold uppercase tracking-wider text-[#191816] mb-2">Specifications:</p>
                  <ul className="space-y-1.5 text-xs text-[#595349]">
                    {product.details.map((detail, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-700 shrink-0 mt-0.5" />
                        <span>{detail}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="mt-6 pt-4 border-t border-[#e2dacb] space-y-2.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  onClick={handleAdd}
                  disabled={!product.inStock}
                  className={`w-full py-3.5 px-4 rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer ${
                    addedAnimation
                      ? 'bg-emerald-700 text-white'
                      : 'bg-[#faf9f5] border-2 border-[#191816] text-[#191816] hover:bg-[#191816] hover:text-white'
                  }`}
                >
                  <ShoppingBag className="w-4 h-4" />
                  {addedAnimation ? 'Added to Bag!' : 'Add to Bag'}
                </button>

                <button
                  onClick={handleBuy}
                  disabled={!product.inStock}
                  className="w-full py-3.5 px-4 rounded-xl bg-[#191816] hover:bg-[#332f2a] text-[#faf9f5] text-xs font-bold uppercase tracking-wider shadow-lg transition-all flex items-center justify-center gap-2 active:scale-95 cursor-pointer"
                >
                  <Zap className="w-4 h-4 text-[#d4af37]" />
                  Order with COD
                </button>
              </div>

              <div className="flex items-center justify-between text-[11px] text-[#70685c] pt-2 px-1">
                <span className="flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-[#d4af37]" /> 24-48h Dhaka Metro
                </span>
                <span className="flex items-center gap-1">
                  <Shield className="w-3.5 h-3.5 text-[#d4af37]" /> Pay Cash on Delivery
                </span>
                <span className="flex items-center gap-1">
                  <RotateCcw className="w-3.5 h-3.5 text-[#d4af37]" /> 7-Day Exchange
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
