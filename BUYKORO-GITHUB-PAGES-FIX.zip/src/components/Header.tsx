import React, { useState } from 'react';
import { ShoppingBag, Search, ShieldCheck, MapPin, Menu, X, ArrowRight } from 'lucide-react';
import { ProductCategory, StoreSettings } from '../types';

interface HeaderProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenAdmin: () => void;
  onOpenTrackOrder: () => void;
  activeCategory: ProductCategory;
  onSelectCategory: (category: ProductCategory) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  storeSettings: StoreSettings;
  isAdminLoggedIn: boolean;
}

const CATEGORIES: ProductCategory[] = [
  'All',
  'Festive Panjabi',
  'Royal Sarees',
  'Luxury Kurtis & Salwar',
  'Contemporary Fusion',
  'Mens Casual',
  'Footwear & Accessories'
];

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  onOpenCart,
  onOpenAdmin,
  onOpenTrackOrder,
  activeCategory,
  onSelectCategory,
  searchQuery,
  onSearchChange,
  storeSettings,
  isAdminLoggedIn
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#faf9f5]/95 backdrop-blur-md border-b border-[#e5e0d3]">
      {/* Top Announcement Bar */}
      <div className="bg-[#191816] text-[#e8dfc8] px-4 py-2 text-xs font-medium tracking-wider flex justify-between items-center">
        <div className="container mx-auto flex items-center justify-between">
          <p className="flex-1 text-center md:text-left truncate">
            {storeSettings.announcement || "🇧🇩 Cash on Delivery across all 64 districts • Free shipping over ৳3,000"}
          </p>
          <div className="hidden md:flex items-center space-x-6 text-[11px] text-[#c5bcab]">
            <button
              onClick={onOpenTrackOrder}
              className="hover:text-[#faf9f5] transition flex items-center gap-1 cursor-pointer"
            >
              <MapPin className="w-3.5 h-3.5 text-[#d4af37]" />
              Track Your Order
            </button>
            <span className="text-[#4a4740]">|</span>
            <button
              onClick={onOpenAdmin}
              className="hover:text-[#faf9f5] transition flex items-center gap-1 cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-[#d4af37]" />
              {isAdminLoggedIn ? 'Admin Portal (Active)' : 'Admin Portal'}
            </button>
            <span className="text-[#4a4740]">|</span>
            <span className="text-[#d4af37] font-semibold">BDT ৳</span>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="container mx-auto px-3 sm:px-6 py-3.5 sm:py-4 flex items-center justify-between gap-2 sm:gap-4">
        {/* Mobile menu trigger */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="lg:hidden p-1.5 sm:p-2 text-[#24211d] hover:bg-[#efebe2] rounded-lg transition cursor-pointer shrink-0"
          aria-label="Toggle navigation menu"
        >
          {mobileMenuOpen ? <X className="w-5 h-5 sm:w-6 sm:h-6" /> : <Menu className="w-5 h-5 sm:w-6 sm:h-6" />}
        </button>

        {/* Brand Logo */}
        <div className="flex items-center space-x-2 sm:space-x-3 cursor-pointer shrink-0" onClick={() => onSelectCategory('All')}>
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-sm bg-[#191816] flex items-center justify-center text-[#d4af37] font-serif font-bold text-lg sm:text-xl shadow-sm border border-[#d4af37]/40">
            B
          </div>
          <div>
            <h1 className="font-serif text-lg sm:text-2xl font-black tracking-[0.18em] sm:tracking-[0.2em] text-[#191816] uppercase leading-none">
              BUYKORO
            </h1>
            <p className="text-[8px] sm:text-[9px] tracking-[0.25em] sm:tracking-[0.3em] uppercase text-[#7a7469] font-medium mt-0.5">
              Dhaka • Couture
            </p>
          </div>
        </div>

        {/* Desktop Category Navigation */}
        <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2">
          {CATEGORIES.map((cat) => {
            const isActive = activeCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => onSelectCategory(cat)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium tracking-wide transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#191816] text-[#faf9f5] shadow-sm'
                    : 'text-[#4d483e] hover:text-[#191816] hover:bg-[#efebe2]'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center space-x-1 sm:space-x-3 shrink-0">
          {/* Search Toggle / Input */}
          <div className="relative">
            {searchOpen ? (
              <div className="flex items-center bg-white border border-[#d6cfbe] rounded-full px-2.5 sm:px-3 py-1.5 shadow-sm w-40 sm:w-64 transition-all">
                <Search className="w-3.5 h-3.5 text-[#7a7469] mr-1.5 shrink-0" />
                <input
                  type="text"
                  placeholder="Search..."
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  className="w-full text-xs bg-transparent focus:outline-none text-[#191816]"
                  autoFocus
                />
                <button
                  onClick={() => {
                    setSearchOpen(false);
                    onSearchChange('');
                  }}
                  className="text-xs text-[#8c8577] hover:text-black ml-1 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setSearchOpen(true)}
                className="p-1.5 sm:p-2 text-[#3b372f] hover:text-[#191816] hover:bg-[#efebe2] rounded-full transition cursor-pointer"
                aria-label="Open search"
              >
                <Search className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
            )}
          </div>

          {/* Quick Track order for mobile */}
          <button
            onClick={onOpenTrackOrder}
            className="md:hidden p-1.5 sm:p-2 text-[#3b372f] hover:text-[#191816] hover:bg-[#efebe2] rounded-full transition cursor-pointer"
            aria-label="Track order"
            title="Track Order"
          >
            <MapPin className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          {/* Bag Button */}
          <button
            onClick={onOpenCart}
            className="relative flex items-center gap-1.5 sm:gap-2 bg-[#191816] text-[#faf9f5] hover:bg-[#2b2723] px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-full shadow-md transition-all active:scale-95 cursor-pointer shrink-0"
            aria-label={`Shopping bag with ${cartCount} items`}
          >
            <ShoppingBag className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#d4af37]" />
            <span className="hidden sm:inline text-xs font-semibold tracking-wider uppercase">Bag</span>
            <span className="w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-[#d4af37] text-[#191816] font-bold text-[10px] sm:text-[11px] flex items-center justify-center">
              {cartCount}
            </span>
          </button>
        </div>
      </div>

      {/* Mobile Category & Links Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#faf9f5] border-b border-[#e5e0d3] px-4 py-4 animate-fadeIn">
          <div className="mb-3">
            <p className="text-[11px] font-semibold text-[#8a8274] uppercase tracking-wider mb-2">
              Collections
            </p>
            <div className="flex flex-wrap gap-1.5">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  onClick={() => {
                    onSelectCategory(cat);
                    setMobileMenuOpen(false);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer ${
                    activeCategory === cat
                      ? 'bg-[#191816] text-[#faf9f5]'
                      : 'bg-white border border-[#e5e0d3] text-[#4d483e]'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-[#e5e0d3] flex flex-col space-y-2 text-xs">
            <button
              onClick={() => {
                onOpenTrackOrder();
                setMobileMenuOpen(false);
              }}
              className="flex items-center justify-between p-2 rounded-lg bg-white border border-[#e5e0d3] text-[#2b2723] font-medium cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#d4af37]" /> Track Existing Order
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-[#8a8274]" />
            </button>
            <button
              onClick={() => {
                onOpenAdmin();
                setMobileMenuOpen(false);
              }}
              className="flex items-center justify-between p-2 rounded-lg bg-white border border-[#e5dfd3] text-[#2b2723] font-medium cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#d4af37]" /> Admin Portal (Staff)
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-[#8a8274]" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
