import React from 'react';
import { Sparkles, Truck, Shield, RotateCcw, ArrowRight } from 'lucide-react';
import { ProductCategory } from '../types';

interface HeroProps {
  onSelectCategory: (cat: ProductCategory) => void;
  onExploreCollection: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onSelectCategory, onExploreCollection }) => {
  return (
    <div className="relative overflow-hidden bg-[#161412] text-[#faf9f5]">
      {/* Background Subtle Gradient & Glow */}
      <div className="absolute inset-0 opacity-25 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-[#d4af37]/40 via-transparent to-transparent pointer-events-none" />

      <div className="container mx-auto px-4 sm:px-6 py-12 md:py-20 lg:py-24 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Text / Editorial Content */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#27231e] border border-[#d4af37]/30 text-[#e6c97a] text-xs font-medium tracking-widest uppercase">
              <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
              New Festive Drop • Eid Couture 2026
            </div>

            <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-light tracking-tight text-[#faf9f5] leading-[1.08]">
              Refining <br />
              <span className="font-serif italic font-normal text-[#e6c97a]">Bangladeshi</span> <br />
              Haute Couture.
            </h1>

            <p className="text-sm sm:text-base text-[#bfb7a7] max-w-xl font-light leading-relaxed">
              From handloom Jamdani silk woven on Rupganj banks to hand-embroidered royal zardozi Panjabis and relaxed linen silhouettes. Crafted for discerning tastes across all 64 districts of Bangladesh.
            </p>

            {/* CTA Buttons */}
            <div className="pt-2 flex flex-wrap items-center gap-3 sm:gap-4">
              <button
                onClick={onExploreCollection}
                className="px-6 sm:px-8 py-3.5 rounded-full bg-[#d4af37] text-[#191816] font-semibold text-xs sm:text-sm tracking-wider uppercase hover:bg-[#e4c259] transition-all shadow-lg active:scale-95 flex items-center gap-2 cursor-pointer"
              >
                Explore Collection
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onSelectCategory('Festive Panjabi')}
                className="px-6 sm:px-8 py-3.5 rounded-full bg-[#27231e] text-[#faf9f5] border border-[#524b3f] hover:border-[#d4af37]/60 text-xs sm:text-sm font-medium tracking-wider uppercase transition-all active:scale-95 cursor-pointer"
              >
                Festive Panjabi
              </button>

              <button
                onClick={() => onSelectCategory('Royal Sarees')}
                className="px-6 sm:px-8 py-3.5 rounded-full bg-[#27231e] text-[#faf9f5] border border-[#524b3f] hover:border-[#d4af37]/60 text-xs sm:text-sm font-medium tracking-wider uppercase transition-all active:scale-95 cursor-pointer"
              >
                Royal Sarees
              </button>
            </div>

            {/* Key Value Points */}
            <div className="pt-6 border-t border-[#312c25] grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs text-[#a89f90]">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-[#d4af37] shrink-0" />
                <span>64 Districts COD</span>
              </div>
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#d4af37] shrink-0" />
                <span>Pure Handloom Weaves</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-[#d4af37] shrink-0" />
                <span>Zero Advance Needed</span>
              </div>
              <div className="flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-[#d4af37] shrink-0" />
                <span>7-Day Easy Exchange</span>
              </div>
            </div>
          </div>

          {/* Right Visual Image Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-sm sm:max-w-md lg:max-w-none">
              <div className="absolute -inset-2 rounded-2xl bg-gradient-to-tr from-[#d4af37]/30 to-transparent blur-sm -z-10" />

              <div className="rounded-2xl overflow-hidden border border-[#443e34] bg-[#221e1a] shadow-2xl relative aspect-[4/5] group">
                <img
                  src="https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=1200&q=85"
                  alt="BUYKORO Heritage Jamdani Silk"
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />

                <div className="absolute bottom-5 left-5 right-5 p-4 rounded-xl bg-[#191816]/90 backdrop-blur-md border border-[#443e34] flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-widest text-[#d4af37]">
                      Heirloom Drop
                    </span>
                    <h3 className="font-serif text-base text-white font-medium">
                      Heritage Jamdani Gold Saree
                    </h3>
                    <p className="text-xs text-[#a89f90]">84-Count Narayanganj Handloom</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] text-[#857b6d] line-through">৳12,500</p>
                    <p className="text-base font-bold text-[#e6c97a]">৳9,800</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
