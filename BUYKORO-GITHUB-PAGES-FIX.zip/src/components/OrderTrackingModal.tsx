import React, { useState, useEffect } from 'react';
import { X, Search, Truck, CheckCircle2, Clock, Package, AlertCircle } from 'lucide-react';
import { Order, OrderStatus } from '../types';
import { lookupOrder } from '../services/storeService';
import { formatBDT } from '../utils/delivery';

interface OrderTrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialOrderId?: string;
}

const STATUS_STEPS: { key: OrderStatus; label: string; desc: string }[] = [
  { key: 'pending', label: 'Order Placed', desc: 'Received & pending verification' },
  { key: 'confirmed', label: 'Confirmed', desc: 'Verified by BUYKORO executive' },
  { key: 'processing', label: 'Packaging', desc: 'Garment packed in luxury box' },
  { key: 'shipped', label: 'Dispatched', desc: 'Handed to courier for delivery' },
  { key: 'delivered', label: 'Delivered', desc: 'Delivered & COD payment collected' }
];

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  isOpen,
  onClose,
  initialOrderId
}) => {
  if (!isOpen) return null;

  const [searchQuery, setSearchQuery] = useState(initialOrderId || '');
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleSearch = async (queryToSearch: string) => {
    if (!queryToSearch.trim()) return;
    setLoading(true);
    setErrorMessage('');
    setSearched(true);

    try {
      const results = await lookupOrder(queryToSearch);
      setOrders(results);
      if (results.length === 0) {
        setErrorMessage(`No orders found matching "${queryToSearch}". Please check your Order ID or phone number.`);
      }
    } catch (err: any) {
      setErrorMessage('Failed to search order. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialOrderId) {
      setSearchQuery(initialOrderId);
      handleSearch(initialOrderId);
    }
  }, [initialOrderId]);

  const getStepIndex = (status: OrderStatus) => {
    if (status === 'cancelled') return -1;
    const idx = STATUS_STEPS.findIndex(s => s.key === status);
    return idx === -1 ? 0 : idx;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-[#faf9f5] rounded-2xl shadow-2xl border border-[#e5dfd3] overflow-hidden my-auto max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-white border-b border-[#e5dfd3] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#191816] text-[#d4af37]">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-[#191816]">
                Track Your BUYKORO Order
              </h2>
              <p className="text-xs text-[#736c61]">
                Real-time Bangladesh parcel tracking via Pathao & Steadfast logistics
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-[#efebe2] text-[#736c61] hover:text-[#191816] transition cursor-pointer"
            aria-label="Close tracking"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {/* Search Box */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSearch(searchQuery);
            }}
            className="flex gap-2"
          >
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-[#8a8274] absolute left-3.5 top-3.5" />
              <input
                type="text"
                placeholder="Enter Order ID (e.g. BK-849201) or 11-digit phone number"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-[#d6cfc1] bg-white text-xs text-[#191816] focus:outline-none focus:ring-1 focus:ring-[#191816] font-mono"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-3 rounded-xl bg-[#191816] hover:bg-[#332f2a] text-[#faf9f5] text-xs font-bold uppercase tracking-wider transition shrink-0 cursor-pointer disabled:opacity-50"
            >
              {loading ? 'Searching...' : 'Track'}
            </button>
          </form>

          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Results */}
          {orders.map((order) => {
            const currentStepIdx = getStepIndex(order.status);
            const isCancelled = order.status === 'cancelled';

            return (
              <div
                key={order.orderId}
                className="p-5 rounded-2xl bg-white border border-[#e5dfd3] shadow-xs space-y-5"
              >
                {/* Order Top Bar */}
                <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-[#f2ede4]">
                  <div>
                    <span className="text-[10px] font-bold text-[#8a8274] uppercase tracking-wider">
                      Order Reference
                    </span>
                    <h3 className="font-mono text-lg font-extrabold text-[#191816]">
                      {order.orderId}
                    </h3>
                  </div>

                  <div className="text-right">
                    <span
                      className={`inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                        isCancelled
                          ? 'bg-red-100 text-red-800'
                          : order.status === 'delivered'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {order.status}
                    </span>
                    <p className="text-[10px] text-[#8a8274] mt-0.5">
                      Placed on {new Date(order.createdAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </p>
                  </div>
                </div>

                {/* Tracking Progress Stepper */}
                {!isCancelled ? (
                  <div className="py-2">
                    <div className="grid grid-cols-5 gap-1 relative">
                      {STATUS_STEPS.map((step, idx) => {
                        const isCompleted = idx <= currentStepIdx;
                        const isCurrent = idx === currentStepIdx;

                        return (
                          <div key={step.key} className="flex flex-col items-center text-center">
                            <div
                              className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold mb-1.5 transition-colors ${
                                isCompleted
                                  ? 'bg-[#191816] text-[#d4af37]'
                                  : 'bg-[#efebe2] text-[#999081]'
                              } ${isCurrent ? 'ring-2 ring-[#d4af37]' : ''}`}
                            >
                              {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                            </div>
                            <span
                              className={`text-[10px] font-bold leading-tight ${
                                isCompleted ? 'text-[#191816]' : 'text-[#999081]'
                              }`}
                            >
                              {step.label}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <div className="p-3 bg-red-50 text-red-700 text-xs rounded-lg">
                    This order has been cancelled. For queries, contact our support desk.
                  </div>
                )}

                {/* Courier Notes & Delivery Address */}
                <div className="p-3.5 rounded-xl bg-[#faf9f5] border border-[#e5dfd3] text-xs space-y-1.5">
                  <div className="flex justify-between text-[#736c61]">
                    <span>Recipient:</span>
                    <span className="font-semibold text-[#191816]">{order.customerName} ({order.phone})</span>
                  </div>
                  <div className="flex justify-between text-[#736c61]">
                    <span>Destination:</span>
                    <span className="font-medium text-[#191816] text-right">{order.address}, {order.district}</span>
                  </div>
                  {order.courierNotes && (
                    <div className="flex justify-between text-blue-800 pt-1 border-t border-[#e2dccf]">
                      <span className="font-semibold">Courier Memo:</span>
                      <span>{order.courierNotes}</span>
                    </div>
                  )}
                </div>

                {/* Items in order */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#191816] mb-2 flex items-center gap-1.5">
                    <Package className="w-3.5 h-3.5 text-[#d4af37]" />
                    Order Items ({order.items.length})
                  </h4>
                  <div className="space-y-2">
                    {order.items.map((item, i) => (
                      <div key={i} className="flex items-center justify-between text-xs py-1.5 border-b border-[#f5f1e8] last:border-none">
                        <div className="flex items-center gap-2">
                          {item.image && (
                            <img src={item.image} alt={item.title} className="w-9 h-10 object-cover rounded bg-[#eee]" />
                          )}
                          <div>
                            <p className="font-medium text-[#191816] line-clamp-1">{item.title}</p>
                            <span className="text-[10px] text-[#8a8274]">Size: {item.size} • Qty: {item.quantity}</span>
                          </div>
                        </div>
                        <span className="font-bold text-[#191816]">
                          {formatBDT(item.price * item.quantity)}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="mt-3 pt-2 border-t border-[#e5dfd3] flex justify-between items-center text-xs">
                    <span className="font-bold text-[#191816]">Total Payable (COD):</span>
                    <span className="font-extrabold text-sm text-[#191816]">{formatBDT(order.total)}</span>
                  </div>
                </div>
              </div>
            );
          })}

          {!searched && (
            <div className="text-center py-8 text-[#8a8274] space-y-2">
              <Clock className="w-8 h-8 mx-auto text-[#b3aa9b]" />
              <p className="text-xs">
                Enter your 6-digit Order ID (printed on your SMS / checkout screen) to see live dispatch milestones.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
