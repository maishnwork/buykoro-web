import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  Package,
  ShoppingBag,
  Truck,
  Settings,
  Plus,
  Trash2,
  Edit3,
  CheckCircle2,
  Phone,
  MessageSquare,
  RefreshCw,
  TrendingUp,
  AlertCircle,
  LogOut,
  Sparkles,
  Lock
} from 'lucide-react';
import { Product, Order, OrderStatus, StoreSettings, UserAuth } from '../types';
import {
  subscribeToOrders,
  updateOrderStatusInFirestore,
  saveProduct,
  deleteProductById,
  seedProductsToFirestore,
  updateStoreConfigInFirestore
} from '../services/storeService';
import { formatBDT } from '../utils/delivery';
import { auth, googleProvider, signInWithPopup, signOut } from '../firebase';

interface AdminPortalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  storeSettings: StoreSettings;
  onSettingsUpdated: (newSettings: StoreSettings) => void;
  userAuth: UserAuth | null;
  onAuthChanged: (user: UserAuth | null) => void;
}

const AUTHORIZED_ADMIN_EMAIL = 'maishn.work@gmail.com';

export const AdminPortal: React.FC<AdminPortalProps> = ({
  isOpen,
  onClose,
  products,
  storeSettings,
  onSettingsUpdated,
  userAuth,
  onAuthChanged
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'orders' | 'inventory' | 'delivery' | 'analytics'>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(true);
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('all');
  const [isDemoBypass, setIsDemoBypass] = useState(false);

  // Delivery Settings Form State
  const [insideDhakaFee, setInsideDhakaFee] = useState(storeSettings.insideDhakaFee || 70);
  const [outsideDhakaFee, setOutsideDhakaFee] = useState(storeSettings.outsideDhakaFee || 130);
  const [freeThreshold, setFreeThreshold] = useState(storeSettings.freeDeliveryThreshold || 3000);
  const [announcementText, setAnnouncementText] = useState(storeSettings.announcement || '');
  const [settingsSaving, setSettingsSaving] = useState(false);
  const [settingsSuccess, setSettingsSuccess] = useState(false);

  // Product Add / Edit Modal State
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [seedingLoading, setSeedingLoading] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState('');

  // Audio notification reference for real-time order alerts
  const [lastOrderCount, setLastOrderCount] = useState<number | null>(null);

  const isAuthorized = Boolean(
    isDemoBypass ||
    (userAuth && (userAuth.isAdmin || userAuth.email === AUTHORIZED_ADMIN_EMAIL))
  );

  // Subscribe to real-time orders when admin is authenticated
  useEffect(() => {
    if (!isOpen || !isAuthorized) return;

    setOrdersLoading(true);
    const unsubscribe = subscribeToOrders(
      (incomingOrders) => {
        // Real-time audio chime if new order arrives
        if (lastOrderCount !== null && incomingOrders.length > lastOrderCount) {
          playNotificationChime();
        }
        setLastOrderCount(incomingOrders.length);
        setOrders(incomingOrders);
        setOrdersLoading(false);
      },
      (err) => {
        console.warn('Orders feed note:', err.message);
        setOrdersLoading(false);
      }
    );

    return () => unsubscribe();
  }, [isOpen, isAuthorized, lastOrderCount]);

  const playNotificationChime = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.15); // A5
      gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.3);
    } catch {
      // AudioContext not allowed without gesture
    }
  };

  const handleGoogleSignIn = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;
      const isAdmin = user.email === AUTHORIZED_ADMIN_EMAIL;
      onAuthChanged({
        uid: user.uid,
        email: user.email,
        displayName: user.displayName,
        photoURL: user.photoURL,
        isAdmin
      });
    } catch (err: any) {
      console.error('Google Sign In failed:', err);
      setFeedbackMessage('Google popup blocked or cancelled. You can use the instant Demo Admin mode.');
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      onAuthChanged(null);
      setIsDemoBypass(false);
    } catch (err) {
      console.error('Sign out error:', err);
    }
  };

  const handleStatusChange = async (orderId: string, newStatus: OrderStatus) => {
    try {
      await updateOrderStatusInFirestore(orderId, newStatus);
      setOrders(prev => prev.map(o => o.orderId === orderId ? { ...o, status: newStatus } : o));
    } catch (err) {
      console.error('Failed to update status:', err);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsSaving(true);
    setSettingsSuccess(false);

    const updated: StoreSettings = {
      ...storeSettings,
      insideDhakaFee: Number(insideDhakaFee),
      outsideDhakaFee: Number(outsideDhakaFee),
      freeDeliveryThreshold: Number(freeThreshold),
      announcement: announcementText.trim()
    };

    try {
      await updateStoreConfigInFirestore(updated);
      onSettingsUpdated(updated);
      setSettingsSuccess(true);
      setTimeout(() => setSettingsSuccess(false), 3000);
    } catch (err) {
      console.error('Failed to save settings:', err);
    } finally {
      setSettingsSaving(false);
    }
  };

  const handleSeedProducts = async () => {
    setSeedingLoading(true);
    setFeedbackMessage('');
    try {
      const count = await seedProductsToFirestore();
      setFeedbackMessage(`Successfully synchronized ${count} luxury fashion items to Firestore!`);
    } catch (err: any) {
      setFeedbackMessage('Seeding error: ' + err.message);
    } finally {
      setSeedingLoading(false);
    }
  };

  const handleSaveProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;

    try {
      await saveProduct(editingProduct);
      setIsProductModalOpen(false);
      setEditingProduct(null);
      setFeedbackMessage('Product catalog successfully updated!');
    } catch (err: any) {
      alert('Error updating product: ' + err.message);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('Are you sure you want to remove this product from the boutique?')) return;
    try {
      await deleteProductById(id);
      setFeedbackMessage('Product removed.');
    } catch (err: any) {
      alert('Error removing product: ' + err.message);
    }
  };

  // Analytics calculations
  const totalRevenue = orders
    .filter(o => o.status !== 'cancelled')
    .reduce((acc, o) => acc + o.total, 0);
  const pendingOrdersCount = orders.filter(o => o.status === 'pending').length;
  const deliveredOrdersCount = orders.filter(o => o.status === 'delivered').length;
  const avgOrderValue = orders.length > 0 ? Math.round(totalRevenue / (orders.length || 1)) : 0;

  const filteredOrders = orders.filter(order => {
    if (selectedStatusFilter === 'all') return true;
    return order.status === selectedStatusFilter;
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 md:p-6 animate-fadeIn">
      <div className="relative w-full max-w-6xl bg-[#faf9f5] rounded-2xl shadow-2xl border border-[#e5dfd3] overflow-hidden my-auto max-h-[95vh] flex flex-col">
        {/* Top Header */}
        <div className="p-4 sm:p-5 bg-[#191816] text-[#faf9f5] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-[#d4af37] text-[#191816]">
              <ShieldCheck className="w-5 h-5 font-bold" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-serif text-lg sm:text-xl font-bold tracking-wider text-[#faf9f5]">
                  BUYKORO Admin Command
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#d4af37] text-[#191816] uppercase">
                  Private Portal
                </span>
              </div>
              <p className="text-xs text-[#b3aa9b]">
                Authorized Admin: <strong className="text-[#e6c97a]">{AUTHORIZED_ADMIN_EMAIL}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {isAuthorized && (
              <button
                onClick={handleSignOut}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#2b2723] hover:bg-[#3d3832] text-xs text-[#d6cfc1] transition"
              >
                <LogOut className="w-3.5 h-3.5" />
                Sign Out
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-[#2b2723] text-[#d6cfc1] hover:text-white transition cursor-pointer"
              aria-label="Close admin portal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Auth Gate Screen if not signed in / not authorized */}
        {!isAuthorized ? (
          <div className="p-8 sm:p-12 text-center max-w-md mx-auto my-auto space-y-6">
            <div className="w-16 h-16 rounded-full bg-amber-50 border border-amber-300 text-amber-800 flex items-center justify-center mx-auto shadow-sm">
              <Lock className="w-8 h-8" />
            </div>

            <div>
              <h3 className="font-serif text-2xl font-bold text-[#191816]">
                Protected Admin Gateway
              </h3>
              <p className="text-xs sm:text-sm text-[#736c61] mt-2 leading-relaxed">
                Access to live order feeds, inventory management, and Bangladesh delivery charge rates is strictly restricted to authorized staff (<span className="font-semibold text-[#191816]">{AUTHORIZED_ADMIN_EMAIL}</span>).
              </p>
            </div>

            <div className="space-y-3 pt-2">
              <button
                onClick={handleGoogleSignIn}
                className="w-full py-3.5 px-4 rounded-xl bg-[#191816] hover:bg-[#332f2a] text-white text-xs font-bold uppercase tracking-wider shadow-md transition flex items-center justify-center gap-3 cursor-pointer"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                Sign In with Google ({AUTHORIZED_ADMIN_EMAIL})
              </button>

              <div className="relative py-2">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-[#e2dccf]" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-[#faf9f5] px-2 text-[#8a8274]">Or Quick Inspection</span>
                </div>
              </div>

              <button
                onClick={() => setIsDemoBypass(true)}
                className="w-full py-3 px-4 rounded-xl bg-white border border-[#d6cfc1] hover:bg-[#efebe2] text-[#191816] text-xs font-semibold uppercase tracking-wider transition cursor-pointer"
              >
                Access Demo Admin Dashboard
              </button>
            </div>

            {feedbackMessage && (
              <p className="text-xs text-amber-800 bg-amber-50 p-2 rounded-lg">
                {feedbackMessage}
              </p>
            )}
          </div>
        ) : (
          /* Authorized Admin Interface */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Admin Navigation Tabs */}
            <div className="bg-[#efebe2] border-b border-[#e2dccf] px-4 sm:px-6 flex items-center justify-between overflow-x-auto shrink-0">
              <div className="flex space-x-1 sm:space-x-2 py-2">
                <button
                  onClick={() => setActiveTab('orders')}
                  className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition flex items-center gap-2 cursor-pointer ${
                    activeTab === 'orders'
                      ? 'bg-[#191816] text-[#faf9f5] shadow-xs'
                      : 'text-[#4d483e] hover:bg-[#e2dacb]'
                  }`}
                >
                  <ShoppingBag className="w-4 h-4 text-[#d4af37]" />
                  Live Orders ({orders.length})
                  {pendingOrdersCount > 0 && (
                    <span className="w-5 h-5 rounded-full bg-amber-500 text-white text-[10px] flex items-center justify-center font-bold">
                      {pendingOrdersCount}
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('inventory')}
                  className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition flex items-center gap-2 cursor-pointer ${
                    activeTab === 'inventory'
                      ? 'bg-[#191816] text-[#faf9f5] shadow-xs'
                      : 'text-[#4d483e] hover:bg-[#e2dacb]'
                  }`}
                >
                  <Package className="w-4 h-4 text-[#d4af37]" />
                  Product Inventory ({products.length})
                </button>

                <button
                  onClick={() => setActiveTab('delivery')}
                  className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition flex items-center gap-2 cursor-pointer ${
                    activeTab === 'delivery'
                      ? 'bg-[#191816] text-[#faf9f5] shadow-xs'
                      : 'text-[#4d483e] hover:bg-[#e2dacb]'
                  }`}
                >
                  <Truck className="w-4 h-4 text-[#d4af37]" />
                  BD Delivery Charges
                </button>

                <button
                  onClick={() => setActiveTab('analytics')}
                  className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition flex items-center gap-2 cursor-pointer ${
                    activeTab === 'analytics'
                      ? 'bg-[#191816] text-[#faf9f5] shadow-xs'
                      : 'text-[#4d483e] hover:bg-[#e2dacb]'
                  }`}
                >
                  <TrendingUp className="w-4 h-4 text-[#d4af37]" />
                  Overview
                </button>
              </div>

              <div className="hidden lg:flex items-center gap-2 text-xs text-[#736c61]">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Live Cloud Feed Connected</span>
              </div>
            </div>

            {/* Notification / Feedback Banner */}
            {feedbackMessage && (
              <div className="bg-emerald-50 border-b border-emerald-200 px-6 py-2.5 text-xs text-emerald-800 flex items-center justify-between">
                <span>{feedbackMessage}</span>
                <button onClick={() => setFeedbackMessage('')} className="font-bold">×</button>
              </div>
            )}

            {/* Tab Contents */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6">
              {/* TAB 1: LIVE ORDERS FEED */}
              {activeTab === 'orders' && (
                <div className="space-y-4">
                  {/* Filter & Action Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-white border border-[#e5dfd3]">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-bold text-[#191816]">Filter Status:</span>
                      {['all', 'pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'].map((status) => (
                        <button
                          key={status}
                          onClick={() => setSelectedStatusFilter(status)}
                          className={`px-2.5 py-1 rounded text-[11px] font-semibold uppercase tracking-wider transition cursor-pointer ${
                            selectedStatusFilter === status
                              ? 'bg-[#191816] text-[#faf9f5]'
                              : 'bg-[#efebe2] text-[#4d483e] hover:bg-[#e2dacb]'
                          }`}
                        >
                          {status}
                        </button>
                      ))}
                    </div>

                    <div className="text-xs text-[#736c61]">
                      Showing {filteredOrders.length} orders
                    </div>
                  </div>

                  {/* Orders Cards List */}
                  {ordersLoading ? (
                    <div className="text-center py-12 text-[#8a8274]">
                      <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-[#d4af37]" />
                      Loading live Firestore order feed...
                    </div>
                  ) : filteredOrders.length === 0 ? (
                    <div className="text-center py-12 bg-white rounded-xl border border-[#e5dfd3] p-8 space-y-3">
                      <ShoppingBag className="w-10 h-10 mx-auto text-[#b3aa9b]" />
                      <h4 className="font-serif text-base font-bold text-[#191816]">
                        No Orders in this Category
                      </h4>
                      <p className="text-xs text-[#736c61]">
                        When customers submit Cash on Delivery checkout orders, they appear here instantly in real-time.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {filteredOrders.map((order) => {
                        const waNumber = order.phone.replace(/^(\+88|88|0)/, '880');
                        return (
                          <div
                            key={order.orderId}
                            className="p-4 sm:p-5 rounded-xl bg-white border border-[#e5dfd3] shadow-xs space-y-4"
                          >
                            <div className="flex flex-wrap items-start justify-between gap-2 pb-3 border-b border-[#f2ede4]">
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="font-mono text-base font-bold text-[#191816]">
                                    {order.orderId}
                                  </span>
                                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#efebe2] text-[#4d483e]">
                                    {order.paymentMethod}
                                  </span>
                                </div>
                                <p className="text-xs text-[#736c61] mt-0.5">
                                  Placed: {new Date(order.createdAt).toLocaleString('en-GB')}
                                </p>
                              </div>

                              {/* Status Selector */}
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-bold text-[#736c61]">Status:</span>
                                <select
                                  value={order.status}
                                  onChange={(e) => handleStatusChange(order.orderId, e.target.value as OrderStatus)}
                                  className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider border cursor-pointer ${
                                    order.status === 'delivered'
                                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                                      : order.status === 'cancelled'
                                      ? 'bg-red-50 text-red-800 border-red-300'
                                      : 'bg-amber-50 text-amber-800 border-amber-300'
                                  }`}
                                >
                                  <option value="pending">Pending</option>
                                  <option value="confirmed">Confirmed</option>
                                  <option value="processing">Processing</option>
                                  <option value="shipped">Shipped</option>
                                  <option value="delivered">Delivered</option>
                                  <option value="cancelled">Cancelled</option>
                                </select>
                              </div>
                            </div>

                            {/* Customer & Address Details */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                              <div className="p-3 rounded-lg bg-[#faf9f5] border border-[#e5dfd3] space-y-1">
                                <p className="font-bold text-[#191816] text-sm">
                                  {order.customerName}
                                </p>
                                <p className="text-[#4d483e] flex items-center gap-2">
                                  <Phone className="w-3.5 h-3.5 text-[#8a8274]" />
                                  <span>{order.phone}</span>
                                  {order.alternativePhone && <span>/ {order.alternativePhone}</span>}
                                </p>
                                <div className="pt-2 flex items-center gap-2">
                                  <a
                                    href={`tel:${order.phone}`}
                                    className="px-2.5 py-1 rounded bg-[#191816] text-white text-[11px] font-semibold hover:bg-[#332f2a] flex items-center gap-1"
                                  >
                                    <Phone className="w-3 h-3" /> Call
                                  </a>
                                  <a
                                    href={`https://wa.me/${waNumber}?text=Assalamu%20Alaikum%20${encodeURIComponent(order.customerName)}%2C%20this%20is%20BUYKORO%20regarding%20your%20Order%20${order.orderId}`}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="px-2.5 py-1 rounded bg-emerald-600 text-white text-[11px] font-semibold hover:bg-emerald-700 flex items-center gap-1"
                                  >
                                    <MessageSquare className="w-3 h-3" /> WhatsApp
                                  </a>
                                </div>
                              </div>

                              <div className="p-3 rounded-lg bg-[#faf9f5] border border-[#e5dfd3] space-y-1">
                                <p className="text-[10px] font-bold text-[#8a8274] uppercase tracking-wider">
                                  Delivery Location
                                </p>
                                <p className="font-semibold text-[#191816]">
                                  {order.district} {order.thana ? `• ${order.thana}` : ''}
                                </p>
                                <p className="text-[#4d483e]">{order.address}</p>
                                {order.instructions && (
                                  <p className="text-amber-800 text-[11px] italic">
                                    Note: "{order.instructions}"
                                  </p>
                                )}
                              </div>
                            </div>

                            {/* Items Purchased List */}
                            <div className="pt-2">
                              <p className="text-[11px] font-bold uppercase tracking-wider text-[#736c61] mb-2">
                                Ordered Products ({order.items.length})
                              </p>
                              <div className="space-y-1.5">
                                {order.items.map((item, idx) => (
                                  <div key={idx} className="flex items-center justify-between text-xs py-1 border-b border-[#f5f1e8] last:border-none">
                                    <span className="font-medium text-[#191816]">
                                      {item.title} (Size: <strong className="text-[#191816]">{item.size}</strong>) × {item.quantity}
                                    </span>
                                    <span className="font-bold text-[#191816]">
                                      {formatBDT(item.price * item.quantity)}
                                    </span>
                                  </div>
                                ))}
                              </div>

                              {/* Cost Totals */}
                              <div className="mt-3 pt-2 border-t border-[#e5dfd3] flex justify-between items-center text-xs">
                                <span className="text-[#736c61]">
                                  Subtotal: {formatBDT(order.subtotal)} • Delivery Fee: {formatBDT(order.deliveryFee)}
                                </span>
                                <div className="text-right">
                                  <span className="text-sm font-extrabold text-[#191816]">
                                    COD Total: {formatBDT(order.total)}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: PRODUCT INVENTORY */}
              {activeTab === 'inventory' && (
                <div className="space-y-4">
                  {/* Inventory Controls */}
                  <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl bg-white border border-[#e5dfd3]">
                    <div>
                      <h3 className="font-serif text-base font-bold text-[#191816]">
                        Boutique Catalog Management
                      </h3>
                      <p className="text-xs text-[#736c61]">
                        Manage clothing items, sizes, fabrics, pricing and stock levels.
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleSeedProducts}
                        disabled={seedingLoading}
                        className="px-3.5 py-2 rounded-xl bg-[#efebe2] hover:bg-[#e2dacb] text-[#191816] text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                        title="Populate/Sync 12 default luxury products into Firestore"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
                        {seedingLoading ? 'Syncing...' : 'Bulk Sync Defaults'}
                      </button>

                      <button
                        onClick={() => {
                          setEditingProduct({
                            id: `prod-${Date.now()}`,
                            title: '',
                            category: 'Festive Panjabi',
                            price: 3500,
                            originalPrice: 4200,
                            description: '',
                            fabric: 'Pure Cotton',
                            sizes: ['38', '40', '42', '44'],
                            images: ['https://images.unsplash.com/photo-1621786030685-2c9777f94b15?auto=format&fit=crop&w=1000&q=80'],
                            inStock: true,
                            stockCount: 15,
                            isFeatured: true,
                            isNewArrival: true,
                            badge: 'New Collection',
                            rating: 4.9,
                            reviewCount: 1,
                            details: ['Handcrafted tailoring', 'Dry clean recommended']
                          });
                          setIsProductModalOpen(true);
                        }}
                        className="px-4 py-2 rounded-xl bg-[#191816] hover:bg-[#332f2a] text-[#faf9f5] text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition cursor-pointer"
                      >
                        <Plus className="w-4 h-4 text-[#d4af37]" />
                        Add New Garment
                      </button>
                    </div>
                  </div>

                  {/* Products Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {products.map((prod) => (
                      <div
                        key={prod.id}
                        className="p-4 rounded-xl bg-white border border-[#e5dfd3] shadow-xs flex flex-col justify-between gap-3"
                      >
                        <div className="flex gap-3">
                          <img
                            src={prod.images?.[0] || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=300&q=80'}
                            alt={prod.title}
                            className="w-16 h-20 object-cover rounded-lg bg-[#eee] shrink-0"
                          />
                          <div className="flex-1 min-w-0">
                            <span className="text-[10px] font-bold text-[#8a8274] uppercase tracking-wider">
                              {prod.category}
                            </span>
                            <h4 className="font-serif text-sm font-bold text-[#191816] truncate">
                              {prod.title}
                            </h4>
                            <p className="text-xs font-semibold text-[#191816] mt-0.5">
                              {formatBDT(prod.price)}
                              {prod.originalPrice && (
                                <span className="ml-1 text-[11px] text-[#8a8274] line-through font-normal">
                                  {formatBDT(prod.originalPrice)}
                                </span>
                              )}
                            </p>
                            <p className="text-[11px] text-[#736c61] truncate mt-0.5">
                              {prod.fabric}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-[#f2ede4] text-xs">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              prod.inStock ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                            }`}
                          >
                            {prod.inStock ? `In Stock (${prod.stockCount || 10})` : 'Out of Stock'}
                          </span>

                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => {
                                setEditingProduct(prod);
                                setIsProductModalOpen(true);
                              }}
                              className="p-1.5 rounded hover:bg-[#efebe2] text-[#4d483e] transition cursor-pointer"
                              title="Edit product"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteProduct(prod.id)}
                              className="p-1.5 rounded hover:bg-red-50 text-red-700 transition cursor-pointer"
                              title="Delete product"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: BANGLADESH DELIVERY CHARGES */}
              {activeTab === 'delivery' && (
                <div className="max-w-2xl bg-white p-6 rounded-2xl border border-[#e5dfd3] shadow-xs space-y-6">
                  <div>
                    <h3 className="font-serif text-lg font-bold text-[#191816]">
                      Bangladesh Delivery Charge Management
                    </h3>
                    <p className="text-xs text-[#736c61] mt-1">
                      Configure standard courier shipping fees for Dhaka Metro, outer districts, and free shipping triggers.
                    </p>
                  </div>

                  {settingsSuccess && (
                    <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                      <span>Delivery rates and store settings updated successfully!</span>
                    </div>
                  )}

                  <form onSubmit={handleSaveSettings} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-[#191816] mb-1">
                          Inside Dhaka Delivery Fee (৳)
                        </label>
                        <input
                          type="number"
                          required
                          value={insideDhakaFee}
                          onChange={(e) => setInsideDhakaFee(Number(e.target.value))}
                          className="w-full px-3.5 py-2.5 rounded-xl border border-[#d6cfc1] text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-[#191816]"
                        />
                        <span className="text-[10px] text-[#8a8274]">
                          Standard Dhaka City courier rate (typically ৳60 - ৳80)
                        </span>
                      </div>

                      <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-[#191816] mb-1">
                          Outside Dhaka Delivery Fee (৳)
                        </label>
                        <input
                          type="number"
                          required
                          value={outsideDhakaFee}
                          onChange={(e) => setOutsideDhakaFee(Number(e.target.value))}
                          className="w-full px-3.5 py-2.5 rounded-xl border border-[#d6cfc1] text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-[#191816]"
                        />
                        <span className="text-[10px] text-[#8a8274]">
                          All other 63 districts & Suburbs (typically ৳120 - ৳150)
                        </span>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#191816] mb-1">
                        Free Shipping Threshold (৳)
                      </label>
                      <input
                        type="number"
                        required
                        value={freeThreshold}
                        onChange={(e) => setFreeThreshold(Number(e.target.value))}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-[#d6cfc1] text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-[#191816]"
                      />
                      <span className="text-[10px] text-[#8a8274]">
                        Cart subtotal that automatically unlocks 0 delivery fee for customer.
                      </span>
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#191816] mb-1">
                        Top Announcement Banner Text
                      </label>
                      <input
                        type="text"
                        value={announcementText}
                        onChange={(e) => setAnnouncementText(e.target.value)}
                        placeholder="e.g. 🇧🇩 Cash on Delivery across all 64 districts • Free shipping over ৳3,000"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-[#d6cfc1] text-xs focus:outline-none focus:ring-1 focus:ring-[#191816]"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={settingsSaving}
                      className="px-6 py-3 rounded-xl bg-[#191816] hover:bg-[#332f2a] text-[#faf9f5] text-xs font-bold uppercase tracking-wider shadow-md transition cursor-pointer disabled:opacity-50"
                    >
                      {settingsSaving ? 'Saving...' : 'Save Settings to Firestore'}
                    </button>
                  </form>
                </div>
              )}

              {/* TAB 4: ANALYTICS OVERVIEW */}
              {activeTab === 'analytics' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="p-5 rounded-2xl bg-white border border-[#e5dfd3] shadow-xs">
                      <p className="text-xs font-bold text-[#8a8274] uppercase tracking-wider">
                        Total Revenue (COD)
                      </p>
                      <p className="font-serif text-2xl font-bold text-[#191816] mt-1">
                        {formatBDT(totalRevenue)}
                      </p>
                      <span className="text-[10px] text-emerald-700 font-medium">Excluding cancelled</span>
                    </div>

                    <div className="p-5 rounded-2xl bg-white border border-[#e5dfd3] shadow-xs">
                      <p className="text-xs font-bold text-[#8a8274] uppercase tracking-wider">
                        Total Orders
                      </p>
                      <p className="font-serif text-2xl font-bold text-[#191816] mt-1">
                        {orders.length}
                      </p>
                      <span className="text-[10px] text-[#736c61]">All time</span>
                    </div>

                    <div className="p-5 rounded-2xl bg-white border border-[#e5dfd3] shadow-xs">
                      <p className="text-xs font-bold text-[#8a8274] uppercase tracking-wider">
                        Pending Verification
                      </p>
                      <p className="font-serif text-2xl font-bold text-amber-700 mt-1">
                        {pendingOrdersCount}
                      </p>
                      <span className="text-[10px] text-[#736c61]">Awaiting phone call</span>
                    </div>

                    <div className="p-5 rounded-2xl bg-white border border-[#e5dfd3] shadow-xs">
                      <p className="text-xs font-bold text-[#8a8274] uppercase tracking-wider">
                        Average Order Value
                      </p>
                      <p className="font-serif text-2xl font-bold text-[#191816] mt-1">
                        {formatBDT(avgOrderValue)}
                      </p>
                      <span className="text-[10px] text-[#736c61]">Per customer basket</span>
                    </div>
                  </div>

                  <div className="p-6 rounded-2xl bg-white border border-[#e5dfd3] shadow-xs">
                    <h3 className="font-serif text-base font-bold text-[#191816] mb-3">
                      Order Fulfillment Distribution
                    </h3>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-center text-xs">
                      <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                        <span className="font-bold text-base text-amber-900 block">{pendingOrdersCount}</span>
                        <span className="text-amber-800">Pending</span>
                      </div>
                      <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                        <span className="font-bold text-base text-blue-900 block">
                          {orders.filter(o => o.status === 'confirmed').length}
                        </span>
                        <span className="text-blue-800">Confirmed</span>
                      </div>
                      <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                        <span className="font-bold text-base text-purple-900 block">
                          {orders.filter(o => o.status === 'processing').length}
                        </span>
                        <span className="text-purple-800">Processing</span>
                      </div>
                      <div className="p-3 rounded-lg bg-sky-50 border border-sky-200">
                        <span className="font-bold text-base text-sky-900 block">
                          {orders.filter(o => o.status === 'shipped').length}
                        </span>
                        <span className="text-sky-800">In Transit</span>
                      </div>
                      <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200">
                        <span className="font-bold text-base text-emerald-900 block">{deliveredOrdersCount}</span>
                        <span className="text-emerald-800">Delivered</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Edit/Add Product Modal */}
      {isProductModalOpen && editingProduct && (
        <div className="fixed inset-0 z-60 bg-black/75 flex items-center justify-center p-3 sm:p-6">
          <div className="bg-[#faf9f5] w-full max-w-lg rounded-2xl p-6 border border-[#e5dfd3] shadow-2xl max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex justify-between items-center border-b border-[#e2dccf] pb-3">
              <h4 className="font-serif text-lg font-bold text-[#191816]">
                {editingProduct.id.includes('new') || !products.find(p => p.id === editingProduct.id)
                  ? 'Add New Luxury Garment'
                  : 'Edit Product Details'}
              </h4>
              <button
                onClick={() => setIsProductModalOpen(false)}
                className="p-1 hover:bg-[#efebe2] rounded"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProductSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold mb-1 text-[#191816]">Product Title</label>
                <input
                  type="text"
                  required
                  value={editingProduct.title}
                  onChange={(e) => setEditingProduct({ ...editingProduct, title: e.target.value })}
                  placeholder="e.g. Royal Jamdani Saree"
                  className="w-full p-2.5 rounded-lg border border-[#d6cfc1] bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1 text-[#191816]">Category</label>
                  <select
                    value={editingProduct.category}
                    onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value as any })}
                    className="w-full p-2.5 rounded-lg border border-[#d6cfc1] bg-white"
                  >
                    <option value="Festive Panjabi">Festive Panjabi</option>
                    <option value="Royal Sarees">Royal Sarees</option>
                    <option value="Luxury Kurtis & Salwar">Luxury Kurtis & Salwar</option>
                    <option value="Contemporary Fusion">Contemporary Fusion</option>
                    <option value="Mens Casual">Mens Casual</option>
                    <option value="Footwear & Accessories">Footwear & Accessories</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold mb-1 text-[#191816]">Fabric / Weave</label>
                  <input
                    type="text"
                    value={editingProduct.fabric}
                    onChange={(e) => setEditingProduct({ ...editingProduct, fabric: e.target.value })}
                    placeholder="e.g. Mulberry Silk"
                    className="w-full p-2.5 rounded-lg border border-[#d6cfc1] bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold mb-1 text-[#191816]">Price (BDT ৳)</label>
                  <input
                    type="number"
                    required
                    value={editingProduct.price}
                    onChange={(e) => setEditingProduct({ ...editingProduct, price: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-lg border border-[#d6cfc1] bg-white"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1 text-[#191816]">Original Price (Cut-off)</label>
                  <input
                    type="number"
                    value={editingProduct.originalPrice || editingProduct.price}
                    onChange={(e) => setEditingProduct({ ...editingProduct, originalPrice: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-lg border border-[#d6cfc1] bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold mb-1 text-[#191816]">Description</label>
                <textarea
                  rows={3}
                  value={editingProduct.description}
                  onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                  className="w-full p-2 rounded-lg border border-[#d6cfc1] bg-white"
                />
              </div>

              <div>
                <label className="block font-bold mb-1 text-[#191816]">Primary Image URL</label>
                <input
                  type="url"
                  value={editingProduct.images?.[0] || ''}
                  onChange={(e) => {
                    const newImages = [...(editingProduct.images || [])];
                    newImages[0] = e.target.value;
                    setEditingProduct({ ...editingProduct, images: newImages });
                  }}
                  className="w-full p-2.5 rounded-lg border border-[#d6cfc1] bg-white"
                />
              </div>

              <div className="flex items-center gap-4 pt-1">
                <label className="flex items-center gap-2 cursor-pointer font-bold">
                  <input
                    type="checkbox"
                    checked={editingProduct.inStock}
                    onChange={(e) => setEditingProduct({ ...editingProduct, inStock: e.target.checked })}
                    className="w-4 h-4 rounded text-[#191816]"
                  />
                  <span>In Stock</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer font-bold">
                  <input
                    type="checkbox"
                    checked={editingProduct.isFeatured}
                    onChange={(e) => setEditingProduct({ ...editingProduct, isFeatured: e.target.checked })}
                    className="w-4 h-4 rounded text-[#191816]"
                  />
                  <span>Featured Drop</span>
                </label>
              </div>

              <div className="pt-3 border-t border-[#e2dccf] flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-white border border-[#d6cfc1]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-[#191816] text-white font-bold"
                >
                  Save to Boutique
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
