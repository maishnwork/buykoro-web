import React from 'react';
import { X, Trash2, ArrowRight, ShoppingBag, ShieldCheck, Truck } from 'lucide-react';
import { CartItem, StoreSettings } from '../types';
import { formatBDT } from '../utils/delivery';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onProceedCheckout: () => void;
  storeSettings: StoreSettings;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onProceedCheckout,
  storeSettings
}) => {
  if (!isOpen) return null;

  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const freeThreshold = storeSettings.freeDeliveryThreshold || 3000;
  const remainingForFree = Math.max(0, freeThreshold - subtotal);
  const progressPercent = Math.min(100, Math.round((subtotal / freeThreshold) * 100));

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-xs transition-opacity animate-fadeIn"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#faf9f5] border-l border-[#e5dfd3] shadow-2xl flex flex-col justify-between">
          <div className="p-5 border-b border-[#e5dfd3] flex items-center justify-between bg-white">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#d4af37]" />
              <h2 className="font-serif text-lg font-bold tracking-wider text-[#191816] uppercase">
                Shopping Bag ({cartItems.reduce((acc, item) => acc + item.quantity, 0)})
              </h2>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-[#f4efe6] text-[#7a7469] hover:text-[#191816] transition cursor-pointer"
              aria-label="Close cart drawer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="bg-[#efebe2] px-5 py-3 border-b border-[#e2dccf]">
            <div className="flex items-center justify-between text-xs mb-1.5 font-medium">
              <span className="flex items-center gap-1.5 text-[#3b362e]">
                <Truck className="w-4 h-4 text-[#d4af37]" />
                {remainingForFree === 0
                  ? "🎉 You've unlocked Free Delivery across Bangladesh!"
                  : `Add ${formatBDT(remainingForFree)} more for Free Delivery!`}
              </span>
              <span className="font-bold text-[#191816]">{progressPercent}%</span>
            </div>
            <div className="w-full h-1.5 bg-[#dbd4c4] rounded-full overflow-hidden">
              <div
                className="h-full bg-[#d4af37] transition-all duration-500 rounded-full"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {cartItems.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
                <div className="w-16 h-16 rounded-full bg-[#efebe2] flex items-center justify-center text-[#999081]">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="font-serif text-base font-semibold text-[#191816]">
                    Your Bag is Empty
                  </h3>
                  <p className="text-xs text-[#736c61] mt-1">
                    Discover exclusive festive Panjabis, Jamdani sarees, and fusion wear.
                  </p>
                </div>
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 rounded-full bg-[#191816] text-[#faf9f5] text-xs font-semibold uppercase tracking-wider hover:bg-[#332f2a] transition cursor-pointer"
                >
                  Start Shopping
                </button>
              </div>
            ) : (
              cartItems.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-3.5 p-3 rounded-xl bg-white border border-[#e5dfd3] shadow-xs relative"
                >
                  <img
                    src={item.product.images?.[0] || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=400&q=80'}
                    alt={item.product.title}
                    className="w-20 h-24 object-cover object-top rounded-lg bg-[#f5f1e8] shrink-0"
                  />

                  <div className="flex-1 flex flex-col justify-between py-0.5">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="font-serif text-sm font-semibold text-[#191816] line-clamp-1">
                          {item.product.title}
                        </h4>
                        <button
                          onClick={() => onRemoveItem(item.id)}
                          className="text-[#999081] hover:text-[#991b1b] p-1 transition cursor-pointer"
                          aria-label={`Remove ${item.product.title}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="flex items-center gap-2 mt-1">
                        <span className="px-2 py-0.5 rounded bg-[#efebe2] text-[#4d483e] text-[10px] font-bold">
                          Size: {item.selectedSize}
                        </span>
                        <span className="text-xs text-[#736c61]">
                          {formatBDT(item.product.price)} each
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#f2ede4]">
                      <div className="flex items-center border border-[#d6cfc1] rounded-md bg-[#faf9f5]">
                        <button
                          onClick={() => onUpdateQuantity(item.id, -1)}
                          className="px-2.5 py-0.5 text-xs font-bold text-[#4d483e] hover:bg-[#efebe2]"
                          aria-label="Decrease quantity"
                        >
                          -
                        </button>
                        <span className="px-2 py-0.5 text-xs font-bold text-[#191816]">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(item.id, 1)}
                          className="px-2.5 py-0.5 text-xs font-bold text-[#4d483e] hover:bg-[#efebe2]"
                          aria-label="Increase quantity"
                        >
                          +
                        </button>
                      </div>

                      <span className="font-bold text-sm text-[#191816]">
                        {formatBDT(item.product.price * item.quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {cartItems.length > 0 && (
            <div className="p-5 border-t border-[#e5dfd3] bg-white space-y-3">
              <div className="flex items-center justify-between text-xs text-[#736c61]">
                <span>Estimated Subtotal</span>
                <span className="text-base font-bold text-[#191816]">{formatBDT(subtotal)}</span>
              </div>

              <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs">
                <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>Zero advance payment needed. Pay Cash on Delivery.</span>
              </div>

              <button
                onClick={() => {
                  onClose();
                  onProceedCheckout();
                }}
                className="w-full py-3.5 px-4 rounded-xl bg-[#191816] hover:bg-[#332f2a] text-[#faf9f5] text-xs font-bold uppercase tracking-wider shadow-xl transition flex items-center justify-center gap-2 active:scale-95 cursor-pointer"
              >
                Proceed to Checkout (COD)
                <ArrowRight className="w-4 h-4 text-[#d4af37]" />
              </button>

              <p className="text-[10px] text-center text-[#8a8274]">
                Free Delivery available on orders over {formatBDT(freeThreshold)} across Bangladesh.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
