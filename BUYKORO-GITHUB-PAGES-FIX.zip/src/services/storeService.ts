import {
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  getDocs,
  where,
  getDoc
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { Product, Order, StoreSettings, OrderStatus } from '../types';
import { DEFAULT_STORE_CONFIG } from '../utils/delivery';
import { SEED_PRODUCTS } from '../data/seedProducts';

const PRODUCTS_COLLECTION = 'products';
const ORDERS_COLLECTION = 'orders';
const SETTINGS_COLLECTION = 'settings';
const SETTINGS_DOC_ID = 'store_config';

export function subscribeToProducts(
  onUpdate: (products: Product[]) => void,
  onError?: (error: Error) => void
): () => void {
  const colRef = collection(db, PRODUCTS_COLLECTION);
  const q = query(colRef);

  const unsubscribe = onSnapshot(
    q,
    (snapshot) => {
      if (snapshot.empty) {
        onUpdate(SEED_PRODUCTS);
      } else {
        const items: Product[] = [];
        snapshot.forEach((docSnap) => {
          items.push({ id: docSnap.id, ...(docSnap.data() as Omit<Product, 'id'>) });
        });
        onUpdate(items);
      }
    },
    (error) => {
      console.warn('Real-time products snapshot note: fallback to seed data', error.message);
      onUpdate(SEED_PRODUCTS);
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.LIST, PRODUCTS_COLLECTION);
    }
  );

  return unsubscribe;
}

export async function saveProduct(product: Product): Promise<void> {
  const docId = product.id || `prod-${Date.now()}`;
  const docRef = doc(db, PRODUCTS_COLLECTION, docId);
  const payload = {
    title: product.title,
    subtitle: product.subtitle || '',
    category: product.category,
    price: Number(product.price),
    originalPrice: product.originalPrice ? Number(product.originalPrice) : Number(product.price),
    description: product.description || '',
    fabric: product.fabric || '',
    sizes: product.sizes || ['Standard'],
    images: product.images && product.images.length > 0 ? product.images : [
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=1000&q=80'
    ],
    inStock: Boolean(product.inStock),
    stockCount: Number(product.stockCount || 10),
    isFeatured: Boolean(product.isFeatured),
    isNewArrival: Boolean(product.isNewArrival),
    badge: product.badge || '',
    rating: Number(product.rating || 4.8),
    reviewCount: Number(product.reviewCount || 12),
    details: product.details || [],
    createdAt: product.createdAt || new Date().toISOString()
  };

  try {
    await setDoc(docRef, payload, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `${PRODUCTS_COLLECTION}/${docId}`);
  }
}

export async function deleteProductById(productId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, PRODUCTS_COLLECTION, productId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `${PRODUCTS_COLLECTION}/${productId}`);
  }
}

export async function seedProductsToFirestore(): Promise<number> {
  let count = 0;
  for (const prod of SEED_PRODUCTS) {
    try {
      await saveProduct(prod);
      count++;
    } catch (e) {
      console.error('Failed to seed item:', prod.title, e);
    }
  }
  return count;
}

const SESSION_ORDERS: Order[] = [];

export async function createOrderInFirestore(order: Order): Promise<Order> {
  const orderDocRef = doc(db, ORDERS_COLLECTION, order.orderId);
  const payload: Order = {
    orderId: order.orderId,
    customerName: order.customerName.trim(),
    phone: order.phone.trim(),
    alternativePhone: order.alternativePhone?.trim() || '',
    district: order.district,
    thana: order.thana?.trim() || '',
    address: order.address.trim(),
    instructions: order.instructions?.trim() || '',
    items: order.items.map(item => ({
      productId: item.productId,
      title: item.title,
      size: item.size,
      price: Number(item.price),
      quantity: Number(item.quantity),
      image: item.image
    })),
    subtotal: Number(order.subtotal),
    deliveryFee: Number(order.deliveryFee),
    total: Number(order.total),
    paymentMethod: 'Cash on Delivery (COD)',
    status: 'pending',
    courierNotes: '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  SESSION_ORDERS.unshift({ id: order.orderId, ...payload });

  try {
    await setDoc(orderDocRef, payload);
    return { id: order.orderId, ...payload };
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `${ORDERS_COLLECTION}/${order.orderId}`);
  }
}

export function subscribeToOrders(
  onUpdate: (orders: Order[]) => void,
  onError?: (error: Error) => void
): () => void {
  const colRef = collection(db, ORDERS_COLLECTION);
  const q = query(colRef, orderBy('createdAt', 'desc'));

  const unsubscribe = onSnapshot(
    q,
    (snapshot) => {
      const orders: Order[] = [];
      snapshot.forEach((docSnap) => {
        orders.push({ id: docSnap.id, ...(docSnap.data() as Omit<Order, 'id'>) });
      });
      onUpdate(orders);
    },
    (error) => {
      // Gracefully supply session orders when admin is testing in demo or offline
      if (SESSION_ORDERS.length > 0) {
        onUpdate([...SESSION_ORDERS]);
      }
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.LIST, ORDERS_COLLECTION);
    }
  );

  return unsubscribe;
}

export async function updateOrderStatusInFirestore(
  orderId: string,
  newStatus: OrderStatus,
  courierNotes?: string
): Promise<void> {
  // Update local session cache
  const idx = SESSION_ORDERS.findIndex(o => o.orderId === orderId);
  if (idx !== -1) {
    SESSION_ORDERS[idx].status = newStatus;
    if (courierNotes !== undefined) {
      SESSION_ORDERS[idx].courierNotes = courierNotes;
    }
    SESSION_ORDERS[idx].updatedAt = new Date().toISOString();
  }

  const docRef = doc(db, ORDERS_COLLECTION, orderId);
  const updateData: Record<string, any> = {
    status: newStatus,
    updatedAt: new Date().toISOString()
  };
  if (courierNotes !== undefined) {
    updateData.courierNotes = courierNotes;
  }

  try {
    await updateDoc(docRef, updateData);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `${ORDERS_COLLECTION}/${orderId}`);
  }
}

export async function lookupOrder(queryText: string): Promise<Order[]> {
  const cleanQuery = queryText.trim();
  if (!cleanQuery) return [];

  try {
    const directDoc = await getDoc(doc(db, ORDERS_COLLECTION, cleanQuery.toUpperCase()));
    if (directDoc.exists()) {
      return [{ id: directDoc.id, ...(directDoc.data() as Omit<Order, 'id'>) }];
    }
  } catch {
    // continue to search
  }

  try {
    const colRef = collection(db, ORDERS_COLLECTION);
    const qPhone = query(colRef, where('phone', '==', cleanQuery));
    const snapPhone = await getDocs(qPhone);
    if (!snapPhone.empty) {
      const results: Order[] = [];
      snapPhone.forEach(docSnap => {
        results.push({ id: docSnap.id, ...(docSnap.data() as Omit<Order, 'id'>) });
      });
      return results;
    }
  } catch (e) {
    console.warn('Phone search note:', e);
  }

  return [];
}

export function subscribeToStoreConfig(
  onUpdate: (config: StoreSettings) => void
): () => void {
  const docRef = doc(db, SETTINGS_COLLECTION, SETTINGS_DOC_ID);
  const unsubscribe = onSnapshot(
    docRef,
    (docSnap) => {
      if (docSnap.exists()) {
        onUpdate(docSnap.data() as StoreSettings);
      } else {
        onUpdate(DEFAULT_STORE_CONFIG);
      }
    },
    () => {
      onUpdate(DEFAULT_STORE_CONFIG);
    }
  );
  return unsubscribe;
}

export async function updateStoreConfigInFirestore(config: StoreSettings): Promise<void> {
  const docRef = doc(db, SETTINGS_COLLECTION, SETTINGS_DOC_ID);
  try {
    await setDoc(docRef, config, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `${SETTINGS_COLLECTION}/${SETTINGS_DOC_ID}`);
  }
}
