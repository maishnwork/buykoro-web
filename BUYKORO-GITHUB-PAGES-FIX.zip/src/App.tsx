/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderTrackingModal } from './components/OrderTrackingModal';
import { AdminPortal } from './components/AdminPortal';
import { Footer } from './components/Footer';

import { Product, ProductCategory, CartItem, Order, StoreSettings, UserAuth } from './types';
import { SEED_PRODUCTS } from './data/seedProducts';
import { DEFAULT_STORE_CONFIG } from './utils/delivery';
import {
  subscribeToProducts,
  subscribeToStoreConfig,
  createOrderInFirestore
} from './services/storeService';
import { auth } from './firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { Filter, ArrowUpDown, CheckCircle2, ShoppingBag } from 'lucide-react';

const LOCAL_STORAGE_CART_KEY = 'buykoro_bag_items_v1';
const AUTHORIZED_ADMIN_EMAIL = 'maishn.work@gmail.com';

export default function App() {
  // Products & Store Config State
  const [products, setProducts] = useState<Product[]>(SEED_PRODUCTS);
  const [storeSettings, setStoreSettings] = useState<StoreSettings>(DEFAULT_STORE_CONFIG);

  // Cart State (hydrated from localStorage)
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_CART_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Auth State
  const [userAuth, setUserAuth] = useState<UserAuth | null>(null);

  // Modals & Navigation State
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isTrackingOpen, setIsTrackingOpen] = useState(false);
  const [trackingOrderId, setTrackingOrderId] = useState<string | undefined>(undefined);
  const [isAdminPortalOpen, setIsAdminPortalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Filters & Search State
  const [activeCategory, setActiveCategory] = useState<ProductCategory>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'rating'>('featured');
  const [inStockOnly, setInStockOnly] = useState(false);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Save cart changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_CART_KEY, JSON.stringify(cartItems));
    } catch {
      // ignore
    }
  }, [cartItems]);

  // Subscribe to Firestore Products & Settings
  useEffect(() => {
    const unsubProducts = subscribeToProducts((loadedProducts) => {
      setProducts(loadedProducts);
    });

    const unsubSettings = subscribeToStoreConfig((loadedConfig) => {
      setStoreSettings(loadedConfig);
    });

    // Listen to Firebase Auth state
    const unsubAuth = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        setUserAuth({
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          displayName: firebaseUser.displayName,
          photoURL: firebaseUser.photoURL,
          isAdmin: firebaseUser.email === AUTHORIZED_ADMIN_EMAIL
        });
      } else {
        setUserAuth(null);
      }
    });

    return () => {
      unsubProducts();
      unsubSettings();
      unsubAuth();
    };
  }, []);

  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Cart Handlers
  const handleAddToCart = (product: Product, size?: string, quantity: number = 1) => {
    const chosenSize = size || product.sizes?.[0] || 'Standard';
    const compositeId = `${product.id}_${chosenSize}`;

    setCartItems((prev) => {
      const existing = prev.find((item) => item.id === compositeId);
      if (existing) {
        return prev.map((item) =>
          item.id === compositeId ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prev, { id: compositeId, product, selectedSize: chosenSize, quantity }];
    });

    showToast(`Added ${product.title} (${chosenSize}) to your Bag!`);
  };

  const handleUpdateQuantity = (cartItemId: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.id === cartItemId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveFromCart = (cartItemId: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== cartItemId));
  };

  const handleDirectBuyNow = (product: Product, size?: string, quantity: number = 1) => {
    handleAddToCart(product, size, quantity);
    setIsCartOpen(false);
    setSelectedProduct(null);
    setIsCheckoutOpen(true);
  };

  const handleOrderPlaced = async (newOrder: Order) => {
    await createOrderInFirestore(newOrder);
    setCartItems([]);
    showToast(`Order ${newOrder.orderId} submitted! We will call you shortly.`);
  };

  // Filtered & Sorted Products
  const filteredProducts = useMemo(() => {
    return products
      .filter((product) => {
        // Category filter
        if (activeCategory !== 'All' && product.category !== activeCategory) {
          return false;
        }
        // In stock filter
        if (inStockOnly && !product.inStock) {
          return false;
        }
        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchTitle = product.title.toLowerCase().includes(q);
          const matchCat = product.category.toLowerCase().includes(q);
          const matchFabric = (product.fabric || '').toLowerCase().includes(q);
          const matchDesc = (product.description || '').toLowerCase().includes(q);
          if (!matchTitle && !matchCat && !matchFabric && !matchDesc) {
            return false;
          }
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price-low') return a.price - b.price;
        if (sortBy === 'price-high') return b.price - a.price;
        if (sortBy === 'rating') return (b.rating || 0) - (a.rating || 0);
        return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
      });
  }, [products, activeCategory, searchQuery, sortBy, inStockOnly]);

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#faf9f5] text-[#191816] flex flex-col font-sans selection:bg-[#d4af37]/30">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#191816] text-[#faf9f5] px-4 py-3 rounded-xl shadow-2xl border border-[#d4af37]/40 flex items-center gap-2.5 text-xs font-semibold animate-slideUp">
          <CheckCircle2 className="w-4 h-4 text-[#d4af37] shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Header */}
      <Header
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAdmin={() => setIsAdminPortalOpen(true)}
        onOpenTrackOrder={() => {
          setTrackingOrderId(undefined);
          setIsTrackingOpen(true);
        }}
        activeCategory={activeCategory}
        onSelectCategory={setActiveCategory}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        storeSettings={storeSettings}
        isAdminLoggedIn={Boolean(userAuth?.isAdmin || userAuth?.email === AUTHORIZED_ADMIN_EMAIL)}
      />

      {/* Hero Section */}
      <Hero
        onSelectCategory={setActiveCategory}
        onExploreCollection={() => {
          const el = document.getElementById('catalog-section');
          el?.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {/* Product Catalog Section */}
      <main id="catalog-section" className="container mx-auto px-4 sm:px-6 py-12 flex-1">
        {/* Section Header & Filters Bar */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-[#e5dfd3]">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#8a8274]">
              <span>Haute Couture Collection</span>
              <span>•</span>
              <span className="text-[#191816]">{activeCategory}</span>
            </div>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#191816] mt-1">
              {activeCategory === 'All' ? 'Curated Bangladeshi Drops' : activeCategory}
            </h2>
            <p className="text-xs text-[#736c61] mt-0.5">
              Showing {filteredProducts.length} bespoke garments available for immediate Cash on Delivery
            </p>
          </div>

          {/* Controls: In-Stock Toggle & Sort */}
          <div className="flex flex-wrap items-center gap-3">
            <label className="flex items-center gap-2 text-xs font-medium text-[#4d483e] cursor-pointer bg-white px-3 py-2 rounded-lg border border-[#e5dfd3]">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={(e) => setInStockOnly(e.target.checked)}
                className="w-3.5 h-3.5 rounded text-[#191816] focus:ring-0"
              />
              <span>In Stock Only</span>
            </label>

            <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-lg border border-[#e5dfd3] text-xs">
              <ArrowUpDown className="w-3.5 h-3.5 text-[#8a8274]" />
              <span className="text-[#8a8274] font-medium">Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-transparent font-semibold text-[#191816] focus:outline-none cursor-pointer"
              >
                <option value="featured">Featured First</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="rating">Top Rated</option>
              </select>
            </div>
          </div>
        </div>

        {/* Category Pills Bar for Quick Switching */}
        <div className="flex items-center gap-2 overflow-x-auto py-4 scrollbar-none">
          {[
            'All',
            'Festive Panjabi',
            'Royal Sarees',
            'Luxury Kurtis & Salwar',
            'Contemporary Fusion',
            'Mens Casual',
            'Footwear & Accessories'
          ].map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat as ProductCategory)}
              className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                activeCategory === cat
                  ? 'bg-[#191816] text-[#faf9f5] shadow-sm'
                  : 'bg-white border border-[#e5dfd3] text-[#4d483e] hover:border-[#191816]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Product Cards Grid */}
        {filteredProducts.length === 0 ? (
          <div className="py-16 text-center space-y-3">
            <Filter className="w-10 h-10 mx-auto text-[#b3aa9b]" />
            <h3 className="font-serif text-lg font-bold text-[#191816]">
              No Products Found
            </h3>
            <p className="text-xs text-[#736c61]">
              Try adjusting your search query or reset category filter.
            </p>
            <button
              onClick={() => {
                setActiveCategory('All');
                setSearchQuery('');
                setInStockOnly(false);
              }}
              className="px-5 py-2 rounded-full bg-[#191816] text-white text-xs font-semibold uppercase tracking-wider"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pt-2">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onQuickView={(p) => setSelectedProduct(p)}
                onAddToCart={(p, size) => handleAddToCart(p, size)}
                onDirectBuyNow={(p, size) => handleDirectBuyNow(p, size)}
              />
            ))}
          </div>
        )}
      </main>

      {/* Floating Mobile Bag Quick-Bar */}
      {totalCartCount > 0 && !isCartOpen && (
        <div className="md:hidden fixed bottom-4 inset-x-4 z-30">
          <button
            onClick={() => setIsCartOpen(true)}
            className="w-full py-3.5 px-5 rounded-2xl bg-[#191816] text-[#faf9f5] shadow-2xl border border-[#d4af37]/40 flex items-center justify-between font-bold text-xs uppercase tracking-wider active:scale-98 transition"
          >
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-[#d4af37]" />
              <span>View Bag ({totalCartCount} items)</span>
            </div>
            <span className="text-[#e6c97a]">Proceed to Checkout →</span>
          </button>
        </div>
      )}

      {/* Modals & Slide-over Drawers */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
        onDirectBuyNow={handleDirectBuyNow}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onProceedCheckout={() => setIsCheckoutOpen(true)}
        storeSettings={storeSettings}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cartItems={cartItems}
        onOrderPlaced={handleOrderPlaced}
        storeSettings={storeSettings}
        onTrackOrder={(orderId) => {
          setTrackingOrderId(orderId);
          setIsTrackingOpen(true);
        }}
      />

      <OrderTrackingModal
        isOpen={isTrackingOpen}
        onClose={() => {
          setIsTrackingOpen(false);
          setTrackingOrderId(undefined);
        }}
        initialOrderId={trackingOrderId}
      />

      <AdminPortal
        isOpen={isAdminPortalOpen}
        onClose={() => setIsAdminPortalOpen(false)}
        products={products}
        storeSettings={storeSettings}
        onSettingsUpdated={setStoreSettings}
        userAuth={userAuth}
        onAuthChanged={setUserAuth}
      />

      {/* Footer */}
      <Footer
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          const el = document.getElementById('catalog-section');
          el?.scrollIntoView({ behavior: 'smooth' });
        }}
        onOpenTrackOrder={() => {
          setTrackingOrderId(undefined);
          setIsTrackingOpen(true);
        }}
        onOpenAdmin={() => setIsAdminPortalOpen(true)}
        storeSettings={storeSettings}
      />
    </div>
  );
}
