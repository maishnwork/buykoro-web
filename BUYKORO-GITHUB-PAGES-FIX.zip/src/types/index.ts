export type ProductCategory =
  | 'All'
  | 'Festive Panjabi'
  | 'Royal Sarees'
  | 'Luxury Kurtis & Salwar'
  | 'Contemporary Fusion'
  | 'Mens Casual'
  | 'Footwear & Accessories';

export interface Product {
  id: string;
  title: string;
  subtitle?: string;
  category: ProductCategory;
  price: number;
  originalPrice?: number;
  description: string;
  fabric: string;
  sizes: string[];
  images: string[];
  inStock: boolean;
  stockCount: number;
  isFeatured: boolean;
  isNewArrival: boolean;
  badge?: string;
  rating: number;
  reviewCount: number;
  details: string[];
  createdAt?: string;
}

export interface CartItem {
  id: string; // composite key: productId_size
  product: Product;
  selectedSize: string;
  quantity: number;
}

export type OrderStatus =
  | 'pending'
  | 'confirmed'
  | 'processing'
  | 'shipped'
  | 'delivered'
  | 'cancelled';

export interface OrderItem {
  productId: string;
  title: string;
  size: string;
  price: number;
  quantity: number;
  image: string;
}

export interface Order {
  id?: string;
  orderId: string;
  customerName: string;
  phone: string;
  alternativePhone?: string;
  district: string;
  thana: string;
  address: string;
  instructions?: string;
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  paymentMethod: 'Cash on Delivery (COD)';
  status: OrderStatus;
  courierNotes?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface StoreSettings {
  insideDhakaFee: number;
  outsideDhakaFee: number;
  freeDeliveryThreshold: number;
  announcement: string;
  supportPhone: string;
  supportWhatsApp: string;
}

export interface UserAuth {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  isAdmin: boolean;
}
