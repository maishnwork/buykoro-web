import { Product } from '../types';

export const SEED_PRODUCTS: Product[] = [
  {
    id: 'prod-001',
    title: 'Heritage Jamdani Gold Silk Saree',
    subtitle: 'Hand-woven 84-count Dhakai Muslin Silk with Zari Motifs',
    category: 'Royal Sarees',
    price: 9800,
    originalPrice: 12500,
    description: 'An heirloom masterpiece handwoven by master weavers in Rupganj, Narayanganj. Features intricate geometric and floral jal motifs in metallic gold and deep midnight navy thread on feather-light organza silk.',
    fabric: 'Pure Dhakai Jamdani Silk (84 Count)',
    sizes: ['Free Size (5.5m + Blouse Piece)'],
    images: [
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=1000&q=80'
    ],
    inStock: true,
    stockCount: 6,
    isFeatured: true,
    isNewArrival: true,
    badge: 'Heritage Collection',
    rating: 4.9,
    reviewCount: 38,
    details: [
      'Authentic handloom Jamdani weaving from Narayanganj',
      'Includes 80cm unstitched matching blouse piece with border work',
      'Feather-soft touch suitable for wedding soirees and festive celebrations',
      'Care: Dry Clean Only. Store wrapped in pure cotton muslin.'
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-002',
    title: 'Imperial Raw Silk Embroidered Panjabi',
    subtitle: 'Zardozi collar detailing with matte horn buttons',
    category: 'Festive Panjabi',
    price: 4650,
    originalPrice: 5800,
    description: 'Tailored from rich raw mulberry silk in deep emerald green. Features understated hand-done bullion wire embroidery along the mandarin collar and concealed placket, paired with modern slim-tapered silhouette.',
    fabric: '100% Raw Mulberry Silk blend',
    sizes: ['38', '40', '42', '44'],
    images: [
      'https://images.unsplash.com/photo-1621786030685-2c9777f94b15?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=1000&q=80'
    ],
    inStock: true,
    stockCount: 14,
    isFeatured: true,
    isNewArrival: true,
    badge: 'Eid Festive Drop',
    rating: 4.8,
    reviewCount: 52,
    details: [
      'Semi-fitted ergonomic cut with side slits and pocket inserts',
      'Pre-shrunk fabric with natural raw silk slub texture',
      'Contrast silk piping along cuffs and hemline',
      'Care: Gentle hand wash or dry clean.'
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-003',
    title: 'Muslin Chiffon Anarkali Kurti & Dupatta',
    subtitle: 'Tiered silhouette with mirror-work yoke & gota patti',
    category: 'Luxury Kurtis & Salwar',
    price: 5200,
    originalPrice: 6500,
    description: 'Flattering floor-length ivory silhouette enhanced with artisanal mirror embroidery on the bodice. Paired with a gossamer organza dupatta accented with scallop hand-embroidered edges.',
    fabric: 'Fine Cotton Muslin & Silk Chiffon',
    sizes: ['S', 'M', 'L', 'XL'],
    images: [
      'https://images.unsplash.com/photo-1583391733975-087dd7dd4759?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=1000&q=80'
    ],
    inStock: true,
    stockCount: 9,
    isFeatured: true,
    isNewArrival: false,
    badge: 'Bestseller',
    rating: 5.0,
    reviewCount: 41,
    details: [
      '2-Piece Ensemble (Anarkali Kurti + Organza Dupatta)',
      'Breathable cotton inner lining for all-day comfort in tropical weather',
      'Gentle flare with over 3.5 meters of hem volume',
      'Care: Cold hand wash with mild shampoo.'
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-004',
    title: 'Katan Banarasi Ruby Wedding Saree',
    subtitle: 'Pure gold zari meenakari border with regal aanchal',
    category: 'Royal Sarees',
    price: 14500,
    originalPrice: 18000,
    description: 'The epitome of Bengali bridal grandeur. Deep crimson red katan silk interwoven with heavy gold floral vines, paisleys, and hand-done turquoise Meenakari accents.',
    fabric: 'Pure Katan Silk with 24k Gold Zari Weave',
    sizes: ['Free Size (6.3m with Heavy Blouse)'],
    images: [
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=1000&q=80'
    ],
    inStock: true,
    stockCount: 4,
    isFeatured: false,
    isNewArrival: true,
    badge: 'Bridal Couture',
    rating: 4.9,
    reviewCount: 29,
    details: [
      'Heavy weight 850 grams pure silk fabric with high drape quality',
      'Intricate pallu/aanchal featuring traditional peacock motifs',
      'Silk Mark certified textile',
      'Care: Strictly Dry Clean Only. Air out every 6 months.'
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-005',
    title: 'Monochrome Linen Short Kurta & Bundi Set',
    subtitle: 'Breathable Irish linen with textured chevron vest',
    category: 'Contemporary Fusion',
    price: 3850,
    originalPrice: 4800,
    description: 'Effortless daytime sophistication. A tailored off-white linen mandarin-collar short kurta complemented by an olive-taupe woven Nehru vest with brass antique buttons.',
    fabric: '60 Lea Irish Linen & Cotton Tweed',
    sizes: ['38', '40', '42', '44'],
    images: [
      'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=1000&q=80'
    ],
    inStock: true,
    stockCount: 18,
    isFeatured: false,
    isNewArrival: true,
    badge: 'New Season',
    rating: 4.7,
    reviewCount: 23,
    details: [
      '2-Piece Fusion set (Short Kurta + Sleeveless Bundi Vest)',
      'Natural moisture-wicking and hyper-breathable linen weave',
      'Slim modern cut designed for loafers or semi-formal trousers',
      'Care: Machine wash cold gentle, iron while slightly damp.'
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-006',
    title: 'Artisan Kolhapuri Handcrafted Leather Mojari',
    subtitle: 'Full-grain vegetable-tanned calfskin with cushioned insole',
    category: 'Footwear & Accessories',
    price: 2450,
    originalPrice: 3200,
    description: 'Traditional Bangladeshi and subcontinental festive footwear hand-stitched by multi-generational cobblers. Features memory-foam cushioned arch support for painless standing through long wedding receptions.',
    fabric: 'Vegetable Tanned Genuine Leather',
    sizes: ['40 (EU 7)', '41 (EU 8)', '42 (EU 9)', '43 (EU 10)', '44 (EU 11)'],
    images: [
      'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&w=1000&q=80'
    ],
    inStock: true,
    stockCount: 22,
    isFeatured: false,
    isNewArrival: false,
    badge: 'Handmade',
    rating: 4.9,
    reviewCount: 64,
    details: [
      '100% Genuine Full-grain leather upper and sole',
      'Double stitched welt for maximum durability',
      'Anti-slip textured rubber heel tread',
      'Care: Treat with neutral leather balm.'
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-007',
    title: 'Midnight Black Kabli Suit with Waistcoat',
    subtitle: 'Pre-washed breathable viscose-cotton with silver crest buttons',
    category: 'Festive Panjabi',
    price: 5400,
    originalPrice: 6800,
    description: 'The definitive royal statement. Rich jet-black long Kabli kurta with matching salwar pajama, topped with a tailored charcoal jacquard waistcoat embellished with metal crest buttons.',
    fabric: 'Viscose Cotton Silk Blend',
    sizes: ['38', '40', '42', '44'],
    images: [
      'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1621786030685-2c9777f94b15?auto=format&fit=crop&w=1000&q=80'
    ],
    inStock: true,
    stockCount: 11,
    isFeatured: true,
    isNewArrival: false,
    badge: 'Signature Style',
    rating: 4.9,
    reviewCount: 77,
    details: [
      'Complete 3-Piece Set: Kabli Kurta, Payjama, and Waistcoat',
      'Fade-resistant jet black reactive dye technology',
      'Structured shoulder contour with premium interlining',
      'Care: Dry Clean Recommended.'
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-008',
    title: 'Lilac Organza Embroidered 3-Piece Salwar Suit',
    subtitle: 'Cutwork lace hemline with pearl-encrusted organza dupatta',
    category: 'Luxury Kurtis & Salwar',
    price: 4950,
    originalPrice: 6200,
    description: 'A romantic pastel masterpiece. Pastel lilac organza long kameez with floral silk-thread embroidery, matched with silk cigarette pants and an airy organza dupatta with pearl border.',
    fabric: 'Fine Organza & Pure Shantoon Silk Lining',
    sizes: ['S', 'M', 'L', 'XL'],
    images: [
      'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1583391733975-087dd7dd4759?auto=format&fit=crop&w=1000&q=80'
    ],
    inStock: true,
    stockCount: 8,
    isFeatured: false,
    isNewArrival: true,
    badge: 'Trending',
    rating: 4.8,
    reviewCount: 33,
    details: [
      'Includes Kameez, Cigarette Pants, and Embroidered Dupatta',
      'Full inner shantoon silk lining attached',
      'Intricate scalloped cutwork embroidery at sleeve cuffs and hem',
      'Care: Dry Clean Only.'
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-009',
    title: 'Pure Khadi Cotton Handloom Everyday Panjabi',
    subtitle: 'Comilla khadi with wooden buttons and neat thread-stitch',
    category: 'Festive Panjabi',
    price: 2150,
    originalPrice: 2600,
    description: 'Crafted from authentic hand-spun Khadi cotton from Comilla. Naturally breathable, lightweight, and gets softer with every wash. Designed for effortless Friday prayers and summer comfort.',
    fabric: '100% Organic Hand-spun Khadi Cotton',
    sizes: ['38', '40', '42', '44'],
    images: [
      'https://images.unsplash.com/photo-1621786030685-2c9777f94b15?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=1000&q=80'
    ],
    inStock: true,
    stockCount: 25,
    isFeatured: false,
    isNewArrival: false,
    badge: 'Everyday Classic',
    rating: 4.6,
    reviewCount: 49,
    details: [
      'Pure organic texture with hand-stitched wooden buttons',
      'Two deep side seam pockets',
      'Eco-friendly low chemical dye process',
      'Care: Gentle cold machine wash.'
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-010',
    title: 'Opal Green Hand-Painted Muslin Dupatta & Stole',
    subtitle: 'Artisan floral brushwork on translucent pure muslin',
    category: 'Footwear & Accessories',
    price: 1850,
    originalPrice: 2400,
    description: 'Each piece is individually hand-painted with watercolor floral art by female craft artisans in Bogura. Drapes gracefully across modern abayas, kurtis, or western blazers.',
    fabric: 'Pure 100-count Translucent Cotton Muslin',
    sizes: ['Free Size (2.5m x 1m)'],
    images: [
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=1000&q=80'
    ],
    inStock: true,
    stockCount: 15,
    isFeatured: false,
    isNewArrival: true,
    badge: 'Artisan Crafted',
    rating: 4.9,
    reviewCount: 27,
    details: [
      'Hand-painted waterproof eco-pigments',
      'Tassel detailing at corners',
      'Multifunctional as formal stole or traditional dupatta',
      'Care: Hand dip wash in cold water with mild liquid soap.'
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-011',
    title: 'Savile Row Cut Cuban Collar Linen Shirt',
    subtitle: 'Relaxed fit vacation & casual evening linen shirt',
    category: 'Mens Casual',
    price: 2250,
    originalPrice: 2900,
    description: 'A contemporary wardrobe staple. Cut from pure washed French flax linen with a relaxed retro camp collar and mother-of-pearl buttons. Unrivaled breathability for Dhaka humidity.',
    fabric: '100% Pure French Flax Linen',
    sizes: ['S', 'M', 'L', 'XL'],
    images: [
      'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=1000&q=80'
    ],
    inStock: true,
    stockCount: 20,
    isFeatured: false,
    isNewArrival: false,
    badge: 'Summer Essential',
    rating: 4.7,
    reviewCount: 31,
    details: [
      'Pre-washed for instant softness with zero shrinkage',
      'Camp cuban open collar with straight hem',
      'Can be worn untucked over chinos or tailored shorts',
      'Care: Machine wash cold, line dry.'
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: 'prod-012',
    title: 'Royal Burgundy Velvet Prince Coat / Sherwani',
    subtitle: 'Hand zardozi crest with gold metallic piping',
    category: 'Contemporary Fusion',
    price: 8900,
    originalPrice: 11500,
    description: 'An elite statement for wedding groomsmen and festive occasions. Tailored from micro-velvet with an imperial structured chest, pocket square detail, and regal brass buttons.',
    fabric: 'Micro-velvet with Satin Silk Lining',
    sizes: ['38', '40', '42', '44'],
    images: [
      'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=1000&q=80'
    ],
    inStock: true,
    stockCount: 5,
    isFeatured: true,
    isNewArrival: false,
    badge: 'Limited Drop',
    rating: 5.0,
    reviewCount: 19,
    details: [
      'Handcrafted bullion crest on chest pocket',
      'Fully canvassed structured fit for sharp posture',
      'Custom gold metallic lining interior',
      'Care: Professional Dry Clean Only.'
    ],
    createdAt: new Date().toISOString()
  }
];
