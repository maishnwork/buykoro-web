/**
 * Bangladesh Delivery and E-Commerce Utility Functions for BUYKORO
 */

export interface StoreConfig {
  insideDhakaFee: number;
  outsideDhakaFee: number;
  freeDeliveryThreshold: number;
  announcement: string;
  supportPhone: string;
  supportWhatsApp: string;
}

export const DEFAULT_STORE_CONFIG: StoreConfig = {
  insideDhakaFee: 70,
  outsideDhakaFee: 130,
  freeDeliveryThreshold: 3000,
  announcement: "🇧🇩 Cash on Delivery across all 64 districts • Free shipping on orders over ৳3,000",
  supportPhone: "+880 1711-000000",
  supportWhatsApp: "+880 1711-000000",
};

export interface DistrictInfo {
  name: string;
  division: string;
  isDhakaCity: boolean;
}

export const BANGLADESH_DISTRICTS: DistrictInfo[] = [
  // Dhaka Division
  { name: 'Dhaka (Inside City)', division: 'Dhaka', isDhakaCity: true },
  { name: 'Dhaka (Suburbs: Savar/Dhamrai/Keraniganj)', division: 'Dhaka', isDhakaCity: false },
  { name: 'Gazipur', division: 'Dhaka', isDhakaCity: false },
  { name: 'Narayanganj', division: 'Dhaka', isDhakaCity: false },
  { name: 'Narsingdi', division: 'Dhaka', isDhakaCity: false },
  { name: 'Munshiganj', division: 'Dhaka', isDhakaCity: false },
  { name: 'Manikganj', division: 'Dhaka', isDhakaCity: false },
  { name: 'Tangail', division: 'Dhaka', isDhakaCity: false },
  { name: 'Kishoreganj', division: 'Dhaka', isDhakaCity: false },
  { name: 'Faridpur', division: 'Dhaka', isDhakaCity: false },
  { name: 'Gopalganj', division: 'Dhaka', isDhakaCity: false },
  { name: 'Madaripur', division: 'Dhaka', isDhakaCity: false },
  { name: 'Rajbari', division: 'Dhaka', isDhakaCity: false },
  { name: 'Shariatpur', division: 'Dhaka', isDhakaCity: false },

  // Chattogram Division
  { name: 'Chattogram', division: 'Chattogram', isDhakaCity: false },
  { name: "Cox's Bazar", division: 'Chattogram', isDhakaCity: false },
  { name: 'Cumilla', division: 'Chattogram', isDhakaCity: false },
  { name: 'Feni', division: 'Chattogram', isDhakaCity: false },
  { name: 'Brahmanbaria', division: 'Chattogram', isDhakaCity: false },
  { name: 'Noakhali', division: 'Chattogram', isDhakaCity: false },
  { name: 'Chandpur', division: 'Chattogram', isDhakaCity: false },
  { name: 'Lakshmipur', division: 'Chattogram', isDhakaCity: false },
  { name: 'Bandarban', division: 'Chattogram', isDhakaCity: false },
  { name: 'Rangamati', division: 'Chattogram', isDhakaCity: false },
  { name: 'Khagrachhari', division: 'Chattogram', isDhakaCity: false },

  // Sylhet Division
  { name: 'Sylhet', division: 'Sylhet', isDhakaCity: false },
  { name: 'Moulvibazar', division: 'Sylhet', isDhakaCity: false },
  { name: 'Habiganj', division: 'Sylhet', isDhakaCity: false },
  { name: 'Sunamganj', division: 'Sylhet', isDhakaCity: false },

  // Rajshahi Division
  { name: 'Rajshahi', division: 'Rajshahi', isDhakaCity: false },
  { name: 'Bogura', division: 'Rajshahi', isDhakaCity: false },
  { name: 'Pabna', division: 'Rajshahi', isDhakaCity: false },
  { name: 'Sirajganj', division: 'Rajshahi', isDhakaCity: false },
  { name: 'Naogaon', division: 'Rajshahi', isDhakaCity: false },
  { name: 'Natore', division: 'Rajshahi', isDhakaCity: false },
  { name: 'Chapai Nawabganj', division: 'Rajshahi', isDhakaCity: false },
  { name: 'Joypurhat', division: 'Rajshahi', isDhakaCity: false },

  // Khulna Division
  { name: 'Khulna', division: 'Khulna', isDhakaCity: false },
  { name: 'Jashore', division: 'Khulna', isDhakaCity: false },
  { name: 'Kushtia', division: 'Khulna', isDhakaCity: false },
  { name: 'Satkhira', division: 'Khulna', isDhakaCity: false },
  { name: 'Bagerhat', division: 'Khulna', isDhakaCity: false },
  { name: 'Jhenaidah', division: 'Khulna', isDhakaCity: false },
  { name: 'Chuadanga', division: 'Khulna', isDhakaCity: false },
  { name: 'Magura', division: 'Khulna', isDhakaCity: false },
  { name: 'Narail', division: 'Khulna', isDhakaCity: false },
  { name: 'Meherpur', division: 'Khulna', isDhakaCity: false },

  // Barishal Division
  { name: 'Barishal', division: 'Barishal', isDhakaCity: false },
  { name: 'Patuakhali', division: 'Barishal', isDhakaCity: false },
  { name: 'Bhola', division: 'Barishal', isDhakaCity: false },
  { name: 'Pirojpur', division: 'Barishal', isDhakaCity: false },
  { name: 'Barguna', division: 'Barishal', isDhakaCity: false },
  { name: 'Jhalokathi', division: 'Barishal', isDhakaCity: false },

  // Rangpur Division
  { name: 'Rangpur', division: 'Rangpur', isDhakaCity: false },
  { name: 'Dinajpur', division: 'Rangpur', isDhakaCity: false },
  { name: 'Gaibandha', division: 'Rangpur', isDhakaCity: false },
  { name: 'Kurigram', division: 'Rangpur', isDhakaCity: false },
  { name: 'Lalmonirhat', division: 'Rangpur', isDhakaCity: false },
  { name: 'Nilphamari', division: 'Rangpur', isDhakaCity: false },
  { name: 'Panchagarh', division: 'Rangpur', isDhakaCity: false },
  { name: 'Thakurgaon', division: 'Rangpur', isDhakaCity: false },

  // Mymensingh Division
  { name: 'Mymensingh', division: 'Mymensingh', isDhakaCity: false },
  { name: 'Jamalpur', division: 'Mymensingh', isDhakaCity: false },
  { name: 'Netrokona', division: 'Mymensingh', isDhakaCity: false },
  { name: 'Sherpur', division: 'Mymensingh', isDhakaCity: false },
];

export function isInsideDhaka(districtName: string): boolean {
  if (!districtName) return false;
  const normalized = districtName.toLowerCase().trim();
  return normalized === 'dhaka (inside city)' || normalized === 'dhaka' || normalized.includes('inside');
}

export function calculateDeliveryFee(
  subtotal: number,
  district: string,
  config: StoreConfig = DEFAULT_STORE_CONFIG
): number {
  if (config.freeDeliveryThreshold > 0 && subtotal >= config.freeDeliveryThreshold) {
    return 0;
  }
  return isInsideDhaka(district) ? config.insideDhakaFee : config.outsideDhakaFee;
}

export function formatBDT(amount: number): string {
  if (isNaN(amount) || amount === null || amount === undefined) {
    return '৳0';
  }
  return `৳${Math.round(amount).toLocaleString('en-IN')}`;
}

export function isValidBdPhone(phone: string): boolean {
  if (!phone) return false;
  const cleaned = phone.replace(/[\s\-\+]/g, '');
  const localMatch = /^01[3-9]\d{8}$/;
  const intlMatch = /^8801[3-9]\d{8}$/;
  return localMatch.test(cleaned) || intlMatch.test(cleaned);
}

export function generateOrderId(): string {
  const num = Math.floor(100000 + Math.random() * 900000);
  return `BK-${num}`;
}

export function calculateDiscountPercent(price: number, originalPrice?: number): number {
  if (!originalPrice || originalPrice <= price) return 0;
  return Math.round(((originalPrice - price) / originalPrice) * 100);
}
