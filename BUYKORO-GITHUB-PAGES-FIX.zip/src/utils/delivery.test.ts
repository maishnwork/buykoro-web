import test from 'node:test';
import assert from 'node:assert/strict';
import {
  isInsideDhaka,
  calculateDeliveryFee,
  isValidBdPhone,
  formatBDT,
  generateOrderId,
  calculateDiscountPercent,
  DEFAULT_STORE_CONFIG
} from './delivery';

test('isInsideDhaka accurately detects Dhaka Metro variations', () => {
  assert.equal(isInsideDhaka('Dhaka (Inside City)'), true);
  assert.equal(isInsideDhaka('Dhaka'), true);
  assert.equal(isInsideDhaka('dhaka'), true);
  assert.equal(isInsideDhaka('Dhaka (Suburbs: Savar/Dhamrai/Keraniganj)'), false);
  assert.equal(isInsideDhaka('Chattogram'), false);
  assert.equal(isInsideDhaka('Sylhet'), false);
  assert.equal(isInsideDhaka(''), false);
});

test('calculateDeliveryFee applies inside/outside Dhaka charges and free shipping threshold', () => {
  const config = { ...DEFAULT_STORE_CONFIG, insideDhakaFee: 70, outsideDhakaFee: 130, freeDeliveryThreshold: 3000 };

  // Subtotal below threshold
  assert.equal(calculateDeliveryFee(1500, 'Dhaka (Inside City)', config), 70);
  assert.equal(calculateDeliveryFee(1500, 'Chattogram', config), 130);
  assert.equal(calculateDeliveryFee(1500, 'Sylhet', config), 130);

  // Subtotal above or equal threshold gets free delivery
  assert.equal(calculateDeliveryFee(3000, 'Dhaka (Inside City)', config), 0);
  assert.equal(calculateDeliveryFee(4500, 'Cox\'s Bazar', config), 0);

  // Custom configuration test
  const customConfig = { ...DEFAULT_STORE_CONFIG, insideDhakaFee: 60, outsideDhakaFee: 120, freeDeliveryThreshold: 2500 };
  assert.equal(calculateDeliveryFee(2000, 'Dhaka (Inside City)', customConfig), 60);
  assert.equal(calculateDeliveryFee(2000, 'Rajshahi', customConfig), 120);
  assert.equal(calculateDeliveryFee(2500, 'Rajshahi', customConfig), 0);
});

test('isValidBdPhone validates authentic Bangladeshi mobile numbers', () => {
  assert.equal(isValidBdPhone('01712345678'), true);
  assert.equal(isValidBdPhone('01812345678'), true);
  assert.equal(isValidBdPhone('01912345678'), true);
  assert.equal(isValidBdPhone('01312345678'), true);
  assert.equal(isValidBdPhone('01412345678'), true);
  assert.equal(isValidBdPhone('01512345678'), true);
  assert.equal(isValidBdPhone('01612345678'), true);
  assert.equal(isValidBdPhone('+8801712345678'), true);
  assert.equal(isValidBdPhone('01712-345678'), true);

  // Invalid numbers
  assert.equal(isValidBdPhone('01212345678'), false);
  assert.equal(isValidBdPhone('01012345678'), false);
  assert.equal(isValidBdPhone('0171234567'), false);
  assert.equal(isValidBdPhone('017123456789'), false);
  assert.equal(isValidBdPhone('abcdefghijk'), false);
  assert.equal(isValidBdPhone(''), false);
});

test('formatBDT formats currency numbers with ৳ symbol and separators', () => {
  assert.equal(formatBDT(1850), '৳1,850');
  assert.equal(formatBDT(70), '৳70');
  assert.equal(formatBDT(125000), '৳1,25,000');
  assert.equal(formatBDT(0), '৳0');
});

test('generateOrderId produces valid BK- prefix format', () => {
  const orderId = generateOrderId();
  assert.match(orderId, /^BK-\d{6}$/);
});

test('calculateDiscountPercent returns correct discount rates', () => {
  assert.equal(calculateDiscountPercent(1800, 2400), 25);
  assert.equal(calculateDiscountPercent(2000, 2000), 0);
  assert.equal(calculateDiscountPercent(2000, 1500), 0);
});
